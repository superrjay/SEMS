<?php
// routes.php - Simple Router for Student Information System

class Router {
    private $routes = [];
    private $basePath = '';
    
    public function __construct() {
        // Detect base path automatically
        $scriptPath = dirname($_SERVER['SCRIPT_NAME']);
        $this->basePath = $scriptPath === '/' ? '' : $scriptPath;
        $this->initRoutes();
    }
    
    private function initRoutes() {
        // Define all routes mapping to actual module files
        $this->routes = [
            // Dashboard
            '' => [
                'file' => 'dashboard.php',
                'title' => 'Dashboard'
            ],
            '/' => [
                'file' => 'dashboard.php',
                'title' => 'Dashboard'
            ],
            'index.php' => [
                'file' => 'dashboard.php',
                'title' => 'Dashboard'
            ],
            
            // Student Management Routes
            'student/register' => [
                'file' => 'modules/student-registration.php',
                'title' => 'Student Registration'
            ],
            'student/registration' => [
                'file' => 'modules/student-registration.php',
                'title' => 'Student Registration'
            ],
            
            'student/update' => [
                'file' => 'modules/student-update.php',
                'title' => 'Update Student Information'
            ],
            'student/edit' => [
                'file' => 'modules/student-update.php',
                'title' => 'Update Student Information'
            ],
            
            'student/search' => [
                'file' => 'modules/student-search.php',
                'title' => 'Search Students'
            ],
            'student/find' => [
                'file' => 'modules/student-search.php',
                'title' => 'Search Students'
            ],
            
            // Academic Routes
            'academic/records' => [
                'file' => 'modules/academic-records.php',
                'title' => 'Academic Records'
            ],
            'academic/view' => [
                'file' => 'modules/academic-records.php',
                'title' => 'Academic Records'
            ],
            
            // Student ID Routes
            'student/id' => [
                'file' => 'modules/student-id.php',
                'title' => 'Student ID Generation'
            ],
            'student/id/generate' => [
                'file' => 'modules/student-id.php',
                'title' => 'Student ID Generation'
            ],
            'id/generate' => [
                'file' => 'modules/student-id.php',
                'title' => 'Student ID Generation'
            ],
            
            // Status Tracking Routes
            'status/tracking' => [
                'file' => 'modules/status-tracking.php',
                'title' => 'Status Tracking'
            ],
            'student/status' => [
                'file' => 'modules/status-tracking.php',
                'title' => 'Status Tracking'
            ],
            
            // Activity Logs Routes
            'activity/logs' => [
                'file' => 'modules/activity-logs.php',
                'title' => 'Activity Logs'
            ],
            'logs' => [
                'file' => 'modules/activity-logs.php',
                'title' => 'Activity Logs'
            ],
            
            // Reports Routes
            'reports' => [
                'file' => 'modules/reports.php',
                'title' => 'Student Reports'
            ],
            'reports/students' => [
                'file' => 'modules/reports.php',
                'title' => 'Student Reports'
            ]
        ];
    }
    
    public function dispatch() {
        // Get the request URI
        $requestUri = $_SERVER['REQUEST_URI'];
        
        // Remove query string
        $path = parse_url($requestUri, PHP_URL_PATH);
        
        // Remove base path
        if ($this->basePath !== '') {
            $path = str_replace($this->basePath, '', $path);
        }
        
        // Remove leading and trailing slashes
        $path = trim($path, '/');
        
        // Remove index.php if present
        $path = str_replace('index.php', '', $path);
        $path = trim($path, '/');
        
        // Find matching route
        $route = $this->findRoute($path);
        
        if ($route) {
            $this->loadRoute($route);
        } else {
            $this->show404();
        }
    }
    
    private function findRoute($path) {
        // Direct match
        if (isset($this->routes[$path])) {
            return $this->routes[$path];
        }
        
        // Try with trailing slash removed
        $pathWithoutSlash = rtrim($path, '/');
        if (isset($this->routes[$pathWithoutSlash])) {
            return $this->routes[$pathWithoutSlash];
        }
        
        // Try with .php extension removed
        $pathWithoutExt = str_replace('.php', '', $path);
        if (isset($this->routes[$pathWithoutExt])) {
            return $this->routes[$pathWithoutExt];
        }
        
        return null;
    }
    
    private function loadRoute($route) {
        $filePath = __DIR__ . '/' . $route['file'];
        
        if (file_exists($filePath)) {
            // Set page title if needed
            if (isset($route['title'])) {
                $GLOBALS['page_title'] = $route['title'];
            }
            
            // Include the file
            require_once $filePath;
        } else {
            $this->show404();
        }
    }
    
    private function show404() {
        http_response_code(404);
        require_once __DIR__ . '/includes/header.php';
        require_once __DIR__ . '/includes/sidebar.php';
        ?>
        <div class="uk-container">
            <div class="uk-card uk-card-default uk-card-body uk-text-center uk-margin-large-top">
                <span uk-icon="icon: warning; ratio: 4" class="uk-margin-bottom"></span>
                <h1 class="uk-heading-medium">404 - Page Not Found</h1>
                <p class="uk-text-lead">The page you're looking for doesn't exist.</p>
                <a href="<?php echo $this->getBaseUrl(); ?>" class="uk-button uk-button-primary uk-margin-top">
                    <span uk-icon="home"></span> Go to Dashboard
                </a>
            </div>
        </div>
        <?php
        require_once __DIR__ . '/includes/footer.php';
    }
    
    public function getBaseUrl() {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        return $protocol . '://' . $host . $this->basePath;
    }
    
    public function url($path) {
        return $this->getBaseUrl() . '/' . ltrim($path, '/');
    }
}

// Helper function to generate URLs
function route($path) {
    global $router;
    return $router->url($path);
}

// Initialize router (if not already done)
if (!isset($router)) {
    $router = new Router();
}
