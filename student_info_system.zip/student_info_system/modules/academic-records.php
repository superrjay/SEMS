<?php
require_once __DIR__ .'/../includes/header.php';
require_once __DIR__ .'/../includes/functions.php';

$student = null;
$academic_records = [];

// Search student
if (isset($_GET['search_student'])) {
    $conn = getDBConnection();
    $search_term = "%{$_GET['student_search']}%";
    
    $sql = "SELECT s.*, p.program_name 
            FROM students s 
            LEFT JOIN programs p ON s.program_id = p.program_id 
            WHERE s.student_number LIKE ? 
               OR CONCAT(s.first_name, ' ', s.last_name) LIKE ?
            LIMIT 1";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $search_term, $search_term);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
        $student_id = $student['student_id'];
        
        // Get academic records
        $record_sql = "SELECT ar.*, sem.semester_name, ay.year_name 
                      FROM academic_records ar
                      LEFT JOIN semesters sem ON ar.semester_id = sem.semester_id
                      LEFT JOIN academic_years ay ON sem.academic_year_id = ay.academic_year_id
                      WHERE ar.student_id = ?
                      ORDER BY ar.created_at DESC";
        
        $record_stmt = $conn->prepare($record_sql);
        $record_stmt->bind_param("i", $student_id);
        $record_stmt->execute();
        $record_result = $record_stmt->get_result();
        
        while ($row = $record_result->fetch_assoc()) {
            $academic_records[] = $row;
        }
        
        $record_stmt->close();
    }
    
    $stmt->close();
    $conn->close();
}
?>

<?php require_once __DIR__ .'/../includes/sidebar.php'; ?>

<div class="uk-container">
    <h1 class="uk-heading-divider">Academic Records Viewer</h1>
    
    <!-- Search Form -->
    <div class="uk-card uk-card-default uk-card-body uk-margin-bottom">
        <form method="GET" class="uk-form-stacked">
            <div class="uk-grid-small" uk-grid>
                <div class="uk-width-3-4@m">
                    <input type="text" class="uk-input" name="student_search" 
                           placeholder="Enter Student Number or Full Name"
                           value="<?php echo $_GET['student_search'] ?? ''; ?>" required>
                </div>
                <div class="uk-width-1-4@m">
                    <button type="submit" name="search_student" class="uk-button uk-button-primary uk-width-1-1">
                        <span uk-icon="search"></span> Search
                    </button>
                </div>
            </div>
        </form>
    </div>
    
    <?php if ($student): ?>
    <!-- Student Information -->
    <div class="uk-card uk-card-primary uk-card-body uk-margin-bottom">
        <div class="uk-grid-small" uk-grid>
            <div class="uk-width-auto">
                <div class="uk-border-circle uk-background-secondary uk-padding-small" style="width: 80px; height: 80px;">
                    <span uk-icon="icon: user; ratio: 2"></span>
                </div>
            </div>
            <div class="uk-width-expand">
                <h2 class="uk-margin-remove"><?php echo "{$student['first_name']} {$student['last_name']}"; ?></h2>
                <p class="uk-text-meta uk-margin-remove">
                    <?php echo $student['student_number']; ?> | 
                    <?php echo $student['program_name']; ?> | 
                    Year <?php echo $student['year_level']; ?>
                </p>
                <p>
                    Status: 
                    <span class="uk-label uk-label-<?php 
                        echo $student['status'] == 'active' ? 'success' : 
                             ($student['status'] == 'graduated' ? 'primary' : 'warning'); 
                    ?>">
                        <?php echo ucfirst($student['status']); ?>
                    </span>
                </p>
            </div>
        </div>
    </div>
    
    <!-- Academic Records -->
    <div class="uk-card uk-card-default uk-card-body">
        <h3>Academic Records</h3>
        
        <?php if (!empty($academic_records)): ?>
        <table class="uk-table uk-table-divider uk-table-striped">
            <thead>
                <tr>
                    <th>Academic Year</th>
                    <th>Semester</th>
                    <th>GPA</th>
                    <th>Units Enrolled</th>
                    <th>Units Earned</th>
                    <th>Academic Status</th>
                    <th>Date Recorded</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($academic_records as $record): ?>
                <tr>
                    <td><?php echo $record['year_name'] ?? 'N/A'; ?></td>
                    <td><?php echo $record['semester_name'] ?? 'N/A'; ?></td>
                    <td>
                        <span class="uk-badge <?php 
                            echo $record['gpa'] >= 3.0 ? 'uk-badge-success' : 
                                 ($record['gpa'] >= 2.0 ? 'uk-badge-warning' : 'uk-badge-danger'); 
                        ?>">
                            <?php echo $record['gpa'] ?? 'N/A'; ?>
                        </span>
                    </td>
                    <td><?php echo $record['total_units_enrolled'] ?? '0'; ?></td>
                    <td><?php echo $record['total_units_earned'] ?? '0'; ?></td>
                    <td>
                        <?php 
                        $status_labels = [
                            'good_standing' => ['label' => 'Good Standing', 'class' => 'uk-label-success'],
                            'probation' => ['label' => 'Probation', 'class' => 'uk-label-warning'],
                            'warning' => ['label' => 'Warning', 'class' => 'uk-label-danger'],
                            'dean_list' => ['label' => 'Dean\'s List', 'class' => 'uk-label-primary']
                        ];
                        $status = $record['academic_status'] ?? 'good_standing';
                        ?>
                        <span class="uk-label <?php echo $status_labels[$status]['class']; ?>">
                            <?php echo $status_labels[$status]['label']; ?>
                        </span>
                    </td>
                    <td><?php echo date('M d, Y', strtotime($record['created_at'])); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="uk-alert-warning" uk-alert>
            <p>No academic records found for this student.</p>
        </div>
        <?php endif; ?>
        
        <!-- Add Academic Record Button (for admin) -->
        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'registrar'): ?>
        <div class="uk-margin-top">
            <button class="uk-button uk-button-primary" uk-toggle="target: #add-record-modal">
                <span uk-icon="plus"></span> Add Academic Record
            </button>
        </div>
        
        <!-- Add Record Modal -->
        <div id="add-record-modal" uk-modal>
            <div class="uk-modal-dialog">
                <button class="uk-modal-close-default" type="button" uk-close></button>
                <div class="uk-modal-header">
                    <h2 class="uk-modal-title">Add Academic Record</h2>
                </div>
                <form method="POST" action="process-record.php">
                    <div class="uk-modal-body">
                        <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">
                        
                        <div class="uk-margin">
                            <label class="uk-form-label">Academic Year</label>
                            <select class="uk-select" name="academic_year_id" required>
                                <?php
                                $conn = getDBConnection();
                                $sql = "SELECT * FROM academic_years ORDER BY start_date DESC";
                                $result = $conn->query($sql);
                                while ($row = $result->fetch_assoc()) {
                                    echo "<option value='{$row['academic_year_id']}'>{$row['year_name']}</option>";
                                }
                                $conn->close();
                                ?>
                            </select>
                        </div>
                        
                        <div class="uk-margin">
                            <label class="uk-form-label">Semester</label>
                            <select class="uk-select" name="semester_id" required>
                                <option value="1">1st Semester</option>
                                <option value="2">2nd Semester</option>
                                <option value="3">Summer</option>
                            </select>
                        </div>
                        
                        <div class="uk-grid-small" uk-grid>
                            <div class="uk-width-1-3">
                                <label class="uk-form-label">GPA</label>
                                <input type="number" class="uk-input" name="gpa" step="0.01" min="0" max="4.0" required>
                            </div>
                            <div class="uk-width-1-3">
                                <label class="uk-form-label">Units Enrolled</label>
                                <input type="number" class="uk-input" name="total_units_enrolled" step="0.5" required>
                            </div>
                            <div class="uk-width-1-3">
                                <label class="uk-form-label">Units Earned</label>
                                <input type="number" class="uk-input" name="total_units_earned" step="0.5" required>
                            </div>
                        </div>
                        
                        <div class="uk-margin">
                            <label class="uk-form-label">Academic Status</label>
                            <select class="uk-select" name="academic_status" required>
                                <option value="good_standing">Good Standing</option>
                                <option value="probation">Probation</option>
                                <option value="warning">Warning</option>
                                <option value="dean_list">Dean's List</option>
                            </select>
                        </div>
                    </div>
                    <div class="uk-modal-footer uk-text-right">
                        <button class="uk-button uk-button-default uk-modal-close" type="button">Cancel</button>
                        <button type="submit" name="add_record" class="uk-button uk-button-primary">Save Record</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <?php elseif (isset($_GET['search_student'])): ?>
    <div class="uk-alert-danger" uk-alert>
        <p>Student not found. Please check the student number or name and try again.</p>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>