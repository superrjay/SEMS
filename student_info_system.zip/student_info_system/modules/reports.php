<?php
require_once __DIR__ .'/../includes/header.php';
require_once __DIR__ .'/../includes/functions.php';

// Get filter parameters
$program_filter = $_GET['program'] ?? 'all';
$status_filter = $_GET['status'] ?? 'all';
$year_filter = $_GET['year'] ?? 'all';

// Get programs for filter
$conn = getDBConnection();
$programs = getAllPrograms();

// Build query
$sql = "SELECT s.*, p.program_name, p.program_code 
        FROM students s 
        LEFT JOIN programs p ON s.program_id = p.program_id 
        WHERE 1=1";

$params = [];
$types = "";

if ($program_filter != 'all') {
    $sql .= " AND s.program_id = ?";
    $params[] = $program_filter;
    $types .= "i";
}

if ($status_filter != 'all') {
    $sql .= " AND s.status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

if ($year_filter != 'all') {
    $sql .= " AND s.year_level = ?";
    $params[] = $year_filter;
    $types .= "i";
}

$sql .= " ORDER BY s.last_name, s.first_name";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$students = [];
while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}

$stmt->close();

// Get statistics
$stats_sql = "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN status = 'graduated' THEN 1 ELSE 0 END) as graduated,
                SUM(CASE WHEN gender = 'male' THEN 1 ELSE 0 END) as male,
                SUM(CASE WHEN gender = 'female' THEN 1 ELSE 0 END) as female
              FROM students";
$stats_result = $conn->query($stats_sql);
$stats = $stats_result->fetch_assoc();

$conn->close();
?>

<?php require_once __DIR__ .'/../includes/sidebar.php'; ?>

<div class="uk-container">
    <h1 class="uk-heading-divider">Student Reports</h1>
    
    <!-- Statistics Cards -->
    <div class="uk-grid-match uk-grid-small uk-margin-bottom" uk-grid>
        <div class="uk-width-1-5@m">
            <div class="uk-card uk-card-primary uk-card-body uk-text-center">
                <h3 class="uk-card-title"><?php echo $stats['total']; ?></h3>
                <p class="uk-text-meta">Total Students</p>
            </div>
        </div>
        <div class="uk-width-1-5@m">
            <div class="uk-card uk-card-success uk-card-body uk-text-center">
                <h3 class="uk-card-title"><?php echo $stats['active']; ?></h3>
                <p class="uk-text-meta">Active</p>
            </div>
        </div>
        <div class="uk-width-1-5@m">
            <div class="uk-card uk-card-default uk-card-body uk-text-center">
                <h3 class="uk-card-title"><?php echo $stats['graduated']; ?></h3>
                <p class="uk-text-meta">Graduated</p>
            </div>
        </div>
        <div class="uk-width-1-5@m">
            <div class="uk-card uk-card-secondary uk-card-body uk-text-center">
                <h3 class="uk-card-title"><?php echo $stats['male']; ?></h3>
                <p class="uk-text-meta">Male</p>
            </div>
        </div>
        <div class="uk-width-1-5@m">
            <div class="uk-card uk-card-secondary uk-card-body uk-text-center">
                <h3 class="uk-card-title"><?php echo $stats['female']; ?></h3>
                <p class="uk-text-meta">Female</p>
            </div>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="uk-card uk-card-default uk-card-body uk-margin-bottom">
        <h3 class="uk-card-title">Filter Reports</h3>
        <form method="GET" class="uk-form-stacked">
            <div class="uk-grid-small" uk-grid>
                <div class="uk-width-1-3@m">
                    <label class="uk-form-label">Program</label>
                    <select class="uk-select" name="program">
                        <option value="all">All Programs</option>
                        <?php foreach ($programs as $program): ?>
                        <option value="<?php echo $program['program_id']; ?>" 
                            <?php echo $program_filter == $program['program_id'] ? 'selected' : ''; ?>>
                            <?php echo $program['program_code']; ?> - <?php echo $program['program_name']; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="uk-width-1-3@m">
                    <label class="uk-form-label">Status</label>
                    <select class="uk-select" name="status">
                        <option value="all">All Statuses</option>
                        <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        <option value="graduated" <?php echo $status_filter == 'graduated' ? 'selected' : ''; ?>>Graduated</option>
                        <option value="dropped" <?php echo $status_filter == 'dropped' ? 'selected' : ''; ?>>Dropped</option>
                        <option value="on_leave" <?php echo $status_filter == 'on_leave' ? 'selected' : ''; ?>>On Leave</option>
                    </select>
                </div>
                <div class="uk-width-1-3@m">
                    <label class="uk-form-label">Year Level</label>
                    <select class="uk-select" name="year">
                        <option value="all">All Years</option>
                        <option value="1" <?php echo $year_filter == '1' ? 'selected' : ''; ?>>1st Year</option>
                        <option value="2" <?php echo $year_filter == '2' ? 'selected' : ''; ?>>2nd Year</option>
                        <option value="3" <?php echo $year_filter == '3' ? 'selected' : ''; ?>>3rd Year</option>
                        <option value="4" <?php echo $year_filter == '4' ? 'selected' : ''; ?>>4th Year</option>
                        <option value="5" <?php echo $year_filter == '5' ? 'selected' : ''; ?>>5th Year</option>
                    </select>
                </div>
            </div>
            <div class="uk-margin-top">
                <button type="submit" class="uk-button uk-button-primary">
                    <span uk-icon="icon: search"></span> Apply Filters
                </button>
                <a href="reports.php" class="uk-button uk-button-default">
                    <span uk-icon="icon: refresh"></span> Reset
                </a>
                <button type="button" class="uk-button uk-button-secondary" onclick="window.print()">
                    <span uk-icon="icon: print"></span> Print Report
                </button>
            </div>
        </form>
    </div>
    
    <!-- Report Results -->
    <div class="uk-card uk-card-default uk-card-body">
        <h3 class="uk-card-title">
            Report Results 
            <span class="uk-badge"><?php echo count($students); ?> students</span>
        </h3>
        
        <?php if (count($students) > 0): ?>
        <div class="uk-overflow-auto">
            <table class="uk-table uk-table-divider uk-table-striped uk-table-small">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student Number</th>
                        <th>Name</th>
                        <th>Program</th>
                        <th>Year</th>
                        <th>Gender</th>
                        <th>Status</th>
                        <th>Admission Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $index => $student): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td><strong><?php echo $student['student_number']; ?></strong></td>
                        <td>
                            <?php 
                            echo $student['last_name'] . ', ' . $student['first_name'];
                            if ($student['middle_name']) {
                                echo ' ' . substr($student['middle_name'], 0, 1) . '.';
                            }
                            ?>
                        </td>
                        <td><?php echo $student['program_code']; ?></td>
                        <td><?php echo $student['year_level']; ?></td>
                        <td><?php echo ucfirst($student['gender']); ?></td>
                        <td>
                            <?php
                            $status_colors = [
                                'active' => 'success',
                                'inactive' => 'warning',
                                'graduated' => 'primary',
                                'dropped' => 'danger',
                                'on_leave' => 'warning'
                            ];
                            $color = $status_colors[$student['status']] ?? 'default';
                            ?>
                            <span class="uk-label uk-label-<?php echo $color; ?>">
                                <?php echo ucfirst(str_replace('_', ' ', $student['status'])); ?>
                            </span>
                        </td>
                        <td><?php echo date('M d, Y', strtotime($student['admission_date'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="uk-alert-warning" uk-alert>
            <p>No students match the selected filters.</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<style media="print">
    .sidebar, .uk-nav, button, .no-print { display: none !important; }
    .uk-width-3-4\@m { width: 100% !important; }
</style>

<?php require_once __DIR__ .'/../includes/footer.php'; ?>
