<?php
require_once __DIR__ .'/../includes/header.php';
require_once __DIR__ .'/../includes/functions.php';

$students = [];
$status_stats = [];

// Get status filter
$status_filter = $_GET['status'] ?? 'all';

// Build query
$conn = getDBConnection();
$sql = "SELECT s.*, p.program_name
        FROM students s 
        LEFT JOIN programs p ON s.program_id = p.program_id 
        WHERE 1=1";

if ($status_filter != 'all') {
    $sql .= " AND s.status = ?";
}

$sql .= " ORDER BY s.last_name, s.first_name";

$stmt = $conn->prepare($sql);
if ($status_filter != 'all') {
    $stmt->bind_param("s", $status_filter);
}

$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}

$stmt->close();

// Get status statistics
$stats_sql = "SELECT status, COUNT(*) as count FROM students GROUP BY status";
$stats_result = $conn->query($stats_sql);
while ($row = $stats_result->fetch_assoc()) {
    $status_stats[$row['status']] = $row['count'];
}

$conn->close();

// Update status if requested
if (isset($_POST['update_status'])) {
    $student_id = $_POST['student_id'];
    $new_status = $_POST['new_status'];
    $reason = $_POST['reason'];
    
    if (updateStudentStatus($student_id, $new_status, $reason, $_SESSION['user_id'])) {
        echo "<script>UIkit.notification({message: 'Student status updated successfully!', status: 'success'})</script>";
        
        // Refresh the page to show updated status
        echo "<script>setTimeout(() => location.reload(), 1500);</script>";
    } else {
        echo "<script>UIkit.notification({message: 'Error updating status', status: 'danger'})</script>";
    }
}
?>

<?php require_once __DIR__ .'/../includes/sidebar.php'; ?>

<div class="uk-container">
    <h1 class="uk-heading-divider">Student Status Tracking</h1>
    
    <!-- Status Statistics -->
    <div class="uk-grid-match uk-grid-small uk-margin-bottom" uk-grid>
        <?php
        $status_colors = [
            'active' => 'primary',
            'inactive' => 'secondary',
            'graduated' => 'success',
            'dropped' => 'danger',
            'on_leave' => 'warning'
        ];
        
        foreach ($status_colors as $status => $color):
            $count = $status_stats[$status] ?? 0;
        ?>
        <div class="uk-width-1-5@m">
            <div class="uk-card uk-card-<?php echo $color; ?> uk-card-body">
                <h3 class="uk-card-title"><?php echo ucfirst($status); ?></h3>
                <p class="uk-text-large"><?php echo $count; ?></p>
                <a href="?status=<?php echo $status; ?>" class="uk-button uk-button-<?php echo $color; ?> uk-button-small">
                    View All
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Filter Tabs -->
    <ul class="uk-subnav uk-subnav-pill" uk-switcher>
        <li class="<?php echo $status_filter == 'all' ? 'uk-active' : ''; ?>">
            <a href="?status=all">All Students</a>
        </li>
        <?php foreach ($status_colors as $status => $color): ?>
        <li class="<?php echo $status_filter == $status ? 'uk-active' : ''; ?>">
            <a href="?status=<?php echo $status; ?>">
                <?php echo ucfirst($status); ?> (<?php echo $status_stats[$status] ?? 0; ?>)
            </a>
        </li>
        <?php endforeach; ?>
    </ul>
    
    <!-- Students Table -->
    <div class="uk-card uk-card-default uk-card-body uk-margin-top">
        <div class="uk-overflow-auto">
            <table class="uk-table uk-table-divider uk-table-hover uk-table-middle">
                <thead>
                    <tr>
                        <th>Student Number</th>
                        <th>Name</th>
                        <th>Program</th>
                        <th>Year Level</th>
                        <th>Current Status</th>
                        <th>Last Update</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student): 
                        // Get status history
                        $conn = getDBConnection();
                        $history_sql = "SELECT * FROM student_status_history 
                                       WHERE student_id = ? 
                                       ORDER BY changed_at DESC LIMIT 1";
                        $history_stmt = $conn->prepare($history_sql);
                        $history_stmt->bind_param("i", $student['student_id']);
                        $history_stmt->execute();
                        $history_result = $history_stmt->get_result();
                        $last_history = $history_result->fetch_assoc();
                        $history_stmt->close();
                        $conn->close();
                    ?>
                    <tr>
                        <td><?php echo $student['student_number']; ?></td>
                        <td>
                            <?php echo "{$student['last_name']}, {$student['first_name']}"; ?>
                            <?php if ($student['middle_name']): ?>
                            <?php echo " {$student['middle_name'][0]}."; ?>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $student['program_name']; ?></td>
                        <td><?php echo $student['year_level']; ?></td>
                        <td>
                            <span class="uk-label uk-label-<?php echo $status_colors[$student['status']]; ?>">
                                <?php echo ucfirst($student['status']); ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($last_history): ?>
                            <small>
                                <?php echo date('M d, Y', strtotime($last_history['changed_at'])); ?><br>
                                <span class="uk-text-meta"><?php echo substr($last_history['reason'], 0, 30) . '...'; ?></span>
                            </small>
                            <?php else: ?>
                            <span class="uk-text-meta">No history</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button class="uk-button uk-button-small uk-button-primary" 
                                    uk-toggle="target: #status-modal-<?php echo $student['student_id']; ?>">
                                Change Status
                            </button>
                            <a href="student-update.php?student_id=<?php echo $student['student_id']; ?>" 
                               class="uk-button uk-button-small uk-button-default">
                                View Details
                            </a>
                        </td>
                    </tr>
                    
                    <!-- Status Change Modal -->
                    <div id="status-modal-<?php echo $student['student_id']; ?>" uk-modal>
                        <div class="uk-modal-dialog">
                            <button class="uk-modal-close-default" type="button" uk-close></button>
                            <div class="uk-modal-header">
                                <h2 class="uk-modal-title">Change Student Status</h2>
                            </div>
                            <form method="POST">
                                <div class="uk-modal-body">
                                    <p><strong>Student:</strong> <?php echo "{$student['first_name']} {$student['last_name']}"; ?></p>
                                    <p><strong>Current Status:</strong> 
                                        <span class="uk-label uk-label-<?php echo $status_colors[$student['status']]; ?>">
                                            <?php echo ucfirst($student['status']); ?>
                                        </span>
                                    </p>
                                    
                                    <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">
                                    
                                    <div class="uk-margin">
                                        <label class="uk-form-label">New Status</label>
                                        <select class="uk-select" name="new_status" required>
                                            <?php foreach ($status_colors as $status_option => $color): ?>
                                            <option value="<?php echo $status_option; ?>" 
                                                <?php echo $student['status'] == $status_option ? 'disabled' : ''; ?>>
                                                <?php echo ucfirst($status_option); ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    
                                    <div class="uk-margin">
                                        <label class="uk-form-label">Reason for Change</label>
                                        <textarea class="uk-textarea" name="reason" rows="3" 
                                                  placeholder="Please provide a reason for the status change..." required></textarea>
                                    </div>
                                </div>
                                <div class="uk-modal-footer uk-text-right">
                                    <button class="uk-button uk-button-default uk-modal-close" type="button">Cancel</button>
                                    <button type="submit" name="update_status" class="uk-button uk-button-primary">Update Status</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <?php if (empty($students)): ?>
        <div class="uk-text-center uk-padding">
            <p class="uk-text-large">No students found with the selected status.</p>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Status History Log -->
    <div class="uk-card uk-card-default uk-card-body uk-margin-top">
        <h3>Recent Status Changes</h3>
        <table class="uk-table uk-table-divider uk-table-small">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Student</th>
                    <th>Previous Status</th>
                    <th>New Status</th>
                    <th>Reason</th>
                    <th>Changed By</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $conn = getDBConnection();
                $history_sql = "SELECT ssh.*, s.student_number, s.first_name, s.last_name, u.username 
                               FROM student_status_history ssh
                               LEFT JOIN students s ON ssh.student_id = s.student_id
                               LEFT JOIN users u ON ssh.changed_by = u.user_id
                               ORDER BY ssh.changed_at DESC 
                               LIMIT 10";
                $result = $conn->query($history_sql);
                
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . date('M d, Y H:i', strtotime($row['changed_at'])) . "</td>";
                        echo "<td>{$row['first_name']} {$row['last_name']} ({$row['student_number']})</td>";
                        echo "<td><span class='uk-label uk-label-default'>" . ucfirst($row['previous_status']) . "</span></td>";
                        echo "<td><span class='uk-label uk-label-" . $status_colors[$row['new_status']] . "'>" . ucfirst($row['new_status']) . "</span></td>";
                        echo "<td>{$row['reason']}</td>";
                        echo "<td>{$row['username']}</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='uk-text-center'>No status change history</td></tr>";
                }
                
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ .'/../includes/footer.php'; ?>