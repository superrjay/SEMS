<?php
require_once __DIR__ .'/../includes/header.php';
require_once __DIR__ .'/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = getDBConnection();
    
    // Get program code for student number generation
    $program_id = $_POST['program_id'];
    $program_sql = "SELECT program_code FROM programs WHERE program_id = ?";
    $stmt = $conn->prepare($program_sql);
    $stmt->bind_param("i", $program_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $program = $result->fetch_assoc();
    $stmt->close();
    
    // Generate student number
    $student_number = generateStudentNumber($program['program_code'], date('Y'));
    
    // Insert student
    $sql = "INSERT INTO students (
        student_number, first_name, middle_name, last_name, suffix,
        email, phone, date_of_birth, gender, civil_status, nationality,
        program_id, year_level, student_type, status, admission_date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    
    $admission_date = date('Y-m-d');
    $status = 'active';
    
    $stmt->bind_param(
        "ssssssssssssisss",
        $student_number,
        $_POST['first_name'],
        $_POST['middle_name'],
        $_POST['last_name'],
        $_POST['suffix'],
        $_POST['email'],
        $_POST['phone'],
        $_POST['date_of_birth'],
        $_POST['gender'],
        $_POST['civil_status'],
        $_POST['nationality'],
        $_POST['program_id'],
        $_POST['year_level'],
        $_POST['student_type'],
        $status,
        $admission_date
    );
    
    if ($stmt->execute()) {
        $student_id = $conn->insert_id;
        
        // Insert personal info
        $personal_sql = "INSERT INTO student_personal_info (
            student_id, present_address, permanent_address,
            emergency_contact_name, emergency_contact_phone,
            father_name, mother_name
        ) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt2 = $conn->prepare($personal_sql);
        $stmt2->bind_param(
            "issssss",
            $student_id,
            $_POST['present_address'],
            $_POST['permanent_address'],
            $_POST['emergency_contact_name'],
            $_POST['emergency_contact_phone'],
            $_POST['father_name'],
            $_POST['mother_name']
        );
        $stmt2->execute();
        $stmt2->close();
        
        // Log activity
        logActivity($_SESSION['user_id'], 'create', 'student_registration', 
                    "Registered new student: $student_number", $student_id);
        
        echo "<script>UIkit.notification({message: 'Student registered successfully! Student Number: $student_number', status: 'success'})</script>";
    } else {
        echo "<script>UIkit.notification({message: 'Error: " . $stmt->error . "', status: 'danger'})</script>";
    }
    
    $stmt->close();
    $conn->close();
}
?>

<?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

<div class="uk-container">
    <h1 class="uk-heading-divider">Student Registration</h1>
    
    <form method="POST" class="uk-form-stacked">
        <div class="uk-grid-match uk-grid-small" uk-grid>
            <!-- Personal Information -->
            <div class="uk-width-1-2@m">
                <div class="uk-card uk-card-default uk-card-body">
                    <h3 class="uk-card-title">Personal Information</h3>
                    
                    <div class="uk-margin">
                        <label class="uk-form-label">First Name *</label>
                        <input type="text" class="uk-input" name="first_name" required>
                    </div>
                    
                    <div class="uk-margin">
                        <label class="uk-form-label">Middle Name</label>
                        <input type="text" class="uk-input" name="middle_name">
                    </div>
                    
                    <div class="uk-margin">
                        <label class="uk-form-label">Last Name *</label>
                        <input type="text" class="uk-input" name="last_name" required>
                    </div>
                    
                    <div class="uk-grid-small" uk-grid>
                        <div class="uk-width-1-4">
                            <label class="uk-form-label">Suffix</label>
                            <input type="text" class="uk-input" name="suffix" placeholder="Jr, III">
                        </div>
                        <div class="uk-width-1-4">
                            <label class="uk-form-label">Gender *</label>
                            <select class="uk-select" name="gender" required>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Date of Birth *</label>
                            <input type="date" class="uk-input" name="date_of_birth" required>
                        </div>
                    </div>
                    
                    <div class="uk-margin">
                        <label class="uk-form-label">Email *</label>
                        <input type="email" class="uk-input" name="email" required>
                    </div>
                    
                    <div class="uk-margin">
                        <label class="uk-form-label">Phone Number</label>
                        <input type="tel" class="uk-input" name="phone">
                    </div>
                </div>
            </div>
            
            <!-- Academic & Contact Information -->
            <div class="uk-width-1-2@m">
                <div class="uk-card uk-card-default uk-card-body">
                    <h3 class="uk-card-title">Academic & Contact Information</h3>
                    
                    <div class="uk-margin">
                        <label class="uk-form-label">Program *</label>
                        <select class="uk-select" name="program_id" required>
                            <option value="">Select Program</option>
                            <?php
                            $programs = getAllPrograms();
                            foreach ($programs as $program) {
                                echo "<option value='{$program['program_id']}'>
                                    {$program['program_code']} - {$program['program_name']}
                                </option>";
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="uk-grid-small" uk-grid>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Year Level *</label>
                            <select class="uk-select" name="year_level" required>
                                <option value="1">1st Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                                <option value="4">4th Year</option>
                                <option value="5">5th Year</option>
                            </select>
                        </div>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Student Type</label>
                            <select class="uk-select" name="student_type">
                                <option value="regular">Regular</option>
                                <option value="irregular">Irregular</option>
                                <option value="transferee">Transferee</option>
                                <option value="shiftee">Shiftee</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="uk-grid-small" uk-grid>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Civil Status</label>
                            <select class="uk-select" name="civil_status">
                                <option value="single">Single</option>
                                <option value="married">Married</option>
                                <option value="widowed">Widowed</option>
                                <option value="separated">Separated</option>
                            </select>
                        </div>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Nationality</label>
                            <input type="text" class="uk-input" name="nationality" value="Filipino">
                        </div>
                    </div>
                    
                    <div class="uk-margin">
                        <label class="uk-form-label">Present Address</label>
                        <textarea class="uk-textarea" name="present_address" rows="2"></textarea>
                    </div>
                    
                    <div class="uk-margin">
                        <label class="uk-form-label">Permanent Address</label>
                        <textarea class="uk-textarea" name="permanent_address" rows="2"></textarea>
                    </div>
                </div>
            </div>
            
            <!-- Family & Emergency Information -->
            <div class="uk-width-1-1">
                <div class="uk-card uk-card-default uk-card-body">
                    <h3 class="uk-card-title">Family & Emergency Information</h3>
                    
                    <div class="uk-grid-small" uk-grid>
                        <div class="uk-width-1-2@m">
                            <label class="uk-form-label">Father's Name</label>
                            <input type="text" class="uk-input" name="father_name">
                        </div>
                        <div class="uk-width-1-2@m">
                            <label class="uk-form-label">Mother's Name</label>
                            <input type="text" class="uk-input" name="mother_name">
                        </div>
                    </div>
                    
                    <div class="uk-grid-small uk-margin-top" uk-grid>
                        <div class="uk-width-1-2@m">
                            <label class="uk-form-label">Emergency Contact Name</label>
                            <input type="text" class="uk-input" name="emergency_contact_name">
                        </div>
                        <div class="uk-width-1-2@m">
                            <label class="uk-form-label">Emergency Contact Phone</label>
                            <input type="tel" class="uk-input" name="emergency_contact_phone">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="uk-margin-large-top">
            <button type="submit" class="uk-button uk-button-primary uk-button-large">
                <span uk-icon="icon: check"></span> Register Student
            </button>
            <button type="reset" class="uk-button uk-button-default uk-button-large">
                <span uk-icon="icon: refresh"></span> Clear Form
            </button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>