<?php
require_once __DIR__ .'/../includes/header.php';
require_once __DIR__ .'/../includes/functions.php';

$search_results = [];
$search_performed = false;

// Search functionality
if (isset($_GET['search'])) {
    $search_performed = true;
    $conn = getDBConnection();
    $search_term = "%{$_GET['search_term']}%";
    
    $sql = "SELECT s.*, p.program_name, p.program_code 
            FROM students s 
            LEFT JOIN programs p ON s.program_id = p.program_id 
            WHERE s.student_number LIKE ? 
               OR s.first_name LIKE ? 
               OR s.last_name LIKE ? 
               OR s.email LIKE ?
               OR CONCAT(s.first_name, ' ', s.last_name) LIKE ?
            ORDER BY s.last_name, s.first_name
            LIMIT 50";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $search_term, $search_term, $search_term, $search_term, $search_term);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $search_results[] = $row;
    }
    
    $stmt->close();
    $conn->close();
}
?>

<?php require_once __DIR__ .'/../includes/sidebar.php'; ?>

<div class="uk-container">
    <h1 class="uk-heading-divider">Search Students</h1>
    
    <!-- Search Form -->
    <div class="uk-card uk-card-default uk-card-body uk-margin-bottom">
        <form method="GET" class="uk-form-stacked">
            <div class="uk-grid-small" uk-grid>
                <div class="uk-width-3-4@m">
                    <label class="uk-form-label">Search by Student Number, Name, or Email</label>
                    <input type="text" class="uk-input uk-form-large" name="search_term" 
                           placeholder="Enter student number, name, or email..."
                           value="<?php echo htmlspecialchars($_GET['search_term'] ?? ''); ?>" required>
                </div>
                <div class="uk-width-1-4@m">
                    <label class="uk-form-label">&nbsp;</label>
                    <button type="submit" name="search" class="uk-button uk-button-primary uk-button-large uk-width-1-1">
                        <span uk-icon="search"></span> Search
                    </button>
                </div>
            </div>
        </form>
    </div>
    
    <?php if ($search_performed): ?>
    <!-- Search Results -->
    <div class="uk-card uk-card-default uk-card-body">
        <h3 class="uk-card-title">
            Search Results 
            <span class="uk-badge"><?php echo count($search_results); ?> found</span>
        </h3>
        
        <?php if (count($search_results) > 0): ?>
        <div class="uk-overflow-auto">
            <table class="uk-table uk-table-divider uk-table-hover uk-table-striped">
                <thead>
                    <tr>
                        <th>Student Number</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Program</th>
                        <th>Year</th>
                        <th>Status</th>
                        <th class="uk-text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($search_results as $student): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($student['student_number']); ?></strong></td>
                        <td>
                            <?php 
                            echo htmlspecialchars($student['last_name'] . ', ' . $student['first_name']);
                            if ($student['middle_name']) {
                                echo ' ' . htmlspecialchars(substr($student['middle_name'], 0, 1)) . '.';
                            }
                            ?>
                        </td>
                        <td><?php echo htmlspecialchars($student['email'] ?? 'N/A'); ?></td>
                        <td>
                            <span class="uk-text-small uk-text-muted"><?php echo htmlspecialchars($student['program_code']); ?></span><br>
                            <?php echo htmlspecialchars($student['program_name']); ?>
                        </td>
                        <td class="uk-text-center"><?php echo $student['year_level']; ?></td>
                        <td>
                            <?php
                            $status_colors = [
                                'active' => 'success',
                                'inactive' => 'warning',
                                'graduated' => 'primary',
                                'dropped' => 'danger',
                                'on_leave' => 'warning'
                            ];
                            $color = $status_colors[$student['status']] ?? 'default';
                            ?>
                            <span class="uk-label uk-label-<?php echo $color; ?>">
                                <?php echo ucfirst(str_replace('_', ' ', $student['status'])); ?>
                            </span>
                        </td>
                        <td class="uk-text-center">
                            <div class="uk-button-group">
                                <a href="student-update.php?student_id=<?php echo $student['student_id']; ?>" 
                                   class="uk-button uk-button-small uk-button-primary" 
                                   uk-tooltip="Edit Student">
                                    <span uk-icon="icon: pencil"></span>
                                </a>
                                <a href="academic-records.php?student_id=<?php echo $student['student_id']; ?>&search_student=1&student_search=<?php echo urlencode($student['student_number']); ?>" 
                                   class="uk-button uk-button-small uk-button-default" 
                                   uk-tooltip="View Records">
                                    <span uk-icon="icon: file-text"></span>
                                </a>
                                <a href="student-id.php?student_id=<?php echo $student['student_id']; ?>&search_id=1&id_search=<?php echo urlencode($student['student_number']); ?>" 
                                   class="uk-button uk-button-small uk-button-default" 
                                   uk-tooltip="Generate ID">
                                    <span uk-icon="icon: credit-card"></span>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="uk-alert-warning" uk-alert>
            <p><strong>No results found.</strong> Try searching with different keywords.</p>
        </div>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <!-- Initial State -->
    <div class="uk-card uk-card-default uk-card-body uk-text-center">
        <span uk-icon="icon: search; ratio: 3" class="uk-margin-bottom"></span>
        <h3>Search for Students</h3>
        <p class="uk-text-muted">Enter a student number, name, or email to find student records.</p>
        
        <div class="uk-margin-large-top">
            <h4>Search Tips:</h4>
            <ul class="uk-list uk-text-left uk-width-1-2@m uk-margin-auto">
                <li><span uk-icon="icon: check"></span> Use partial names (e.g., "John" will find "John Doe")</li>
                <li><span uk-icon="icon: check"></span> Search by student number for exact matches</li>
                <li><span uk-icon="icon: check"></span> Email addresses are also searchable</li>
                <li><span uk-icon="icon: check"></span> Search is case-insensitive</li>
            </ul>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Quick Stats -->
    <?php
    $conn = getDBConnection();
    $stats_sql = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                    SUM(CASE WHEN status = 'graduated' THEN 1 ELSE 0 END) as graduated,
                    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive
                  FROM students";
    $stats_result = $conn->query($stats_sql);
    $stats = $stats_result->fetch_assoc();
    $conn->close();
    ?>
    
    <div class="uk-grid-match uk-grid-small uk-margin-top" uk-grid>
        <div class="uk-width-1-4@m">
            <div class="uk-card uk-card-primary uk-card-body uk-text-center">
                <h3 class="uk-card-title"><?php echo $stats['total']; ?></h3>
                <p class="uk-text-meta">Total Students</p>
            </div>
        </div>
        <div class="uk-width-1-4@m">
            <div class="uk-card uk-card-success uk-card-body uk-text-center">
                <h3 class="uk-card-title"><?php echo $stats['active']; ?></h3>
                <p class="uk-text-meta">Active</p>
            </div>
        </div>
        <div class="uk-width-1-4@m">
            <div class="uk-card uk-card-default uk-card-body uk-text-center">
                <h3 class="uk-card-title"><?php echo $stats['graduated']; ?></h3>
                <p class="uk-text-meta">Graduated</p>
            </div>
        </div>
        <div class="uk-width-1-4@m">
            <div class="uk-card uk-card-secondary uk-card-body uk-text-center">
                <h3 class="uk-card-title"><?php echo $stats['inactive']; ?></h3>
                <p class="uk-text-meta">Inactive</p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ .'/../includes/footer.php'; ?>
