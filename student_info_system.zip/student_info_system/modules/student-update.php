<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/functions.php';


$search_results = [];
$selected_student = null;

// Search functionality
if (isset($_GET['search'])) {
    $conn = getDBConnection();
    $search_term = "%{$_GET['search_term']}%";
    
    $sql = "SELECT s.*, p.program_name 
            FROM students s 
            LEFT JOIN programs p ON s.program_id = p.program_id 
            WHERE s.student_number LIKE ? 
               OR s.first_name LIKE ? 
               OR s.last_name LIKE ? 
               OR s.email LIKE ?
            ORDER BY s.last_name, s.first_name
            LIMIT 20";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $search_term, $search_term, $search_term, $search_term);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $search_results[] = $row;
    }
    
    $stmt->close();
    $conn->close();
}

// Get specific student for editing
if (isset($_GET['student_id'])) {
    $selected_student = getStudentById($_GET['student_id']);
    
    // Get personal info
    if ($selected_student) {
        $conn = getDBConnection();
        $sql = "SELECT * FROM student_personal_info WHERE student_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $_GET['student_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $personal_info = $result->fetch_assoc();
        
        $selected_student = array_merge($selected_student, $personal_info ?: []);
        
        $stmt->close();
        $conn->close();
    }
}

// Update functionality
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_student'])) {
    $conn = getDBConnection();
    
    // Update student table
    $sql = "UPDATE students SET 
            first_name = ?, middle_name = ?, last_name = ?, suffix = ?,
            email = ?, phone = ?, date_of_birth = ?, gender = ?,
            civil_status = ?, nationality = ?, program_id = ?,
            year_level = ?, student_type = ?
            WHERE student_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "ssssssssssisisi",
        $_POST['first_name'],
        $_POST['middle_name'],
        $_POST['last_name'],
        $_POST['suffix'],
        $_POST['email'],
        $_POST['phone'],
        $_POST['date_of_birth'],
        $_POST['gender'],
        $_POST['civil_status'],
        $_POST['nationality'],
        $_POST['program_id'],
        $_POST['year_level'],
        $_POST['student_type'],
        $_POST['student_id']
    );
    
    if ($stmt->execute()) {
        // Update or insert personal info
        $check_sql = "SELECT info_id FROM student_personal_info WHERE student_id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $_POST['student_id']);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            // Update existing
            $update_sql = "UPDATE student_personal_info SET 
                          present_address = ?, permanent_address = ?,
                          emergency_contact_name = ?, emergency_contact_phone = ?,
                          father_name = ?, mother_name = ?
                          WHERE student_id = ?";
        } else {
            // Insert new
            $update_sql = "INSERT INTO student_personal_info 
                          (student_id, present_address, permanent_address,
                           emergency_contact_name, emergency_contact_phone,
                           father_name, mother_name)
                          VALUES (?, ?, ?, ?, ?, ?, ?)";
        }
        
        $update_stmt = $conn->prepare($update_sql);
        
        if ($check_result->num_rows > 0) {
            $update_stmt->bind_param(
                "ssssssi",
                $_POST['present_address'],
                $_POST['permanent_address'],
                $_POST['emergency_contact_name'],
                $_POST['emergency_contact_phone'],
                $_POST['father_name'],
                $_POST['mother_name'],
                $_POST['student_id']
            );
        } else {
            $update_stmt->bind_param(
                "issssss",
                $_POST['student_id'],
                $_POST['present_address'],
                $_POST['permanent_address'],
                $_POST['emergency_contact_name'],
                $_POST['emergency_contact_phone'],
                $_POST['father_name'],
                $_POST['mother_name']
            );
        }
        
        $update_stmt->execute();
        $update_stmt->close();
        $check_stmt->close();
        
        // Log activity
        logActivity($_SESSION['user_id'], 'update', 'student_information', 
                    "Updated information for student ID: {$_POST['student_id']}", 
                    $_POST['student_id']);
        
        echo "<script>UIkit.notification({message: 'Student information updated successfully!', status: 'success'})</script>";
        
        // Refresh student data
        $selected_student = getStudentById($_POST['student_id']);
        $conn = getDBConnection();
        $sql = "SELECT * FROM student_personal_info WHERE student_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $_POST['student_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $personal_info = $result->fetch_assoc();
        $selected_student = array_merge($selected_student, $personal_info ?: []);
        $stmt->close();
        $conn->close();
    } else {
        echo "<script>UIkit.notification({message: 'Error: " . $stmt->error . "', status: 'danger'})</script>";
    }
    
    $stmt->close();
    $conn->close();
}
?>

<?php require_once __DIR__ .'/../includes/sidebar.php'; ?>

<div class="uk-container">
    <h1 class="uk-heading-divider">Update Student Information</h1>
    
    <!-- Search Form -->
    <div class="uk-card uk-card-default uk-card-body uk-margin-bottom">
        <form method="GET" class="uk-form-stacked">
            <div class="uk-grid-small" uk-grid>
                <div class="uk-width-3-4@m">
                    <input type="text" class="uk-input" name="search_term" 
                           placeholder="Search by Student Number, Name, or Email"
                           value="<?php echo $_GET['search_term'] ?? ''; ?>">
                </div>
                <div class="uk-width-1-4@m">
                    <button type="submit" name="search" class="uk-button uk-button-primary uk-width-1-1">
                        <span uk-icon="search"></span> Search
                    </button>
                </div>
            </div>
        </form>
    </div>
    
    <!-- Search Results -->
    <?php if (!empty($search_results) && !isset($_GET['student_id'])): ?>
    <div class="uk-card uk-card-default uk-card-body">
        <h3>Search Results</h3>
        <table class="uk-table uk-table-divider uk-table-hover">
            <thead>
                <tr>
                    <th>Student Number</th>
                    <th>Name</th>
                    <th>Program</th>
                    <th>Year Level</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($search_results as $student): ?>
                <tr>
                    <td><?php echo $student['student_number']; ?></td>
                    <td><?php echo "{$student['last_name']}, {$student['first_name']}"; ?></td>
                    <td><?php echo $student['program_name']; ?></td>
                    <td><?php echo $student['year_level']; ?></td>
                    <td>
                        <span class="uk-label uk-label-<?php 
                            echo $student['status'] == 'active' ? 'success' : 
                                 ($student['status'] == 'graduated' ? 'primary' : 'warning'); 
                        ?>">
                            <?php echo ucfirst($student['status']); ?>
                        </span>
                    </td>
                    <td>
                        <a href="?student_id=<?php echo $student['student_id']; ?>" 
                           class="uk-button uk-button-small uk-button-primary">
                            <span uk-icon="pencil"></span> Edit
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    
    <!-- Edit Form -->
    <?php if ($selected_student): ?>
    <form method="POST" class="uk-form-stacked uk-margin-top">
        <input type="hidden" name="student_id" value="<?php echo $selected_student['student_id']; ?>">
        <input type="hidden" name="update_student" value="1">
        
        <div class="uk-grid-match uk-grid-small" uk-grid>
            <div class="uk-width-1-3@m">
                <div class="uk-card uk-card-primary uk-card-body">
                    <h3 class="uk-card-title">Student Information</h3>
                    <p><strong>Student Number:</strong><br><?php echo $selected_student['student_number']; ?></p>
                    <p><strong>Admission Date:</strong><br><?php echo date('M d, Y', strtotime($selected_student['admission_date'])); ?></p>
                    <p><strong>Current Status:</strong><br>
                        <span class="uk-label uk-label-<?php 
                            echo $selected_student['status'] == 'active' ? 'success' : 
                                 ($selected_student['status'] == 'graduated' ? 'primary' : 'warning'); 
                        ?>">
                            <?php echo ucfirst($selected_student['status']); ?>
                        </span>
                    </p>
                </div>
            </div>
            
            <div class="uk-width-2-3@m">
                <div class="uk-card uk-card-default uk-card-body">
                    <h3 class="uk-card-title">Edit Details</h3>
                    
                    <div class="uk-grid-small" uk-grid>
                        <div class="uk-width-1-3">
                            <label class="uk-form-label">First Name *</label>
                            <input type="text" class="uk-input" name="first_name" 
                                   value="<?php echo $selected_student['first_name']; ?>" required>
                        </div>
                        <div class="uk-width-1-3">
                            <label class="uk-form-label">Middle Name</label>
                            <input type="text" class="uk-input" name="middle_name" 
                                   value="<?php echo $selected_student['middle_name'] ?? ''; ?>">
                        </div>
                        <div class="uk-width-1-3">
                            <label class="uk-form-label">Last Name *</label>
                            <input type="text" class="uk-input" name="last_name" 
                                   value="<?php echo $selected_student['last_name']; ?>" required>
                        </div>
                    </div>
                    
                    <div class="uk-grid-small uk-margin-top" uk-grid>
                        <div class="uk-width-1-4">
                            <label class="uk-form-label">Suffix</label>
                            <input type="text" class="uk-input" name="suffix" 
                                   value="<?php echo $selected_student['suffix'] ?? ''; ?>">
                        </div>
                        <div class="uk-width-1-4">
                            <label class="uk-form-label">Gender *</label>
                            <select class="uk-select" name="gender" required>
                                <option value="male" <?php echo $selected_student['gender'] == 'male' ? 'selected' : ''; ?>>Male</option>
                                <option value="female" <?php echo $selected_student['gender'] == 'female' ? 'selected' : ''; ?>>Female</option>
                                <option value="other" <?php echo $selected_student['gender'] == 'other' ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Date of Birth *</label>
                            <input type="date" class="uk-input" name="date_of_birth" 
                                   value="<?php echo $selected_student['date_of_birth']; ?>" required>
                        </div>
                    </div>
                    
                    <div class="uk-grid-small uk-margin-top" uk-grid>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Email *</label>
                            <input type="email" class="uk-input" name="email" 
                                   value="<?php echo $selected_student['email']; ?>" required>
                        </div>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Phone</label>
                            <input type="tel" class="uk-input" name="phone" 
                                   value="<?php echo $selected_student['phone'] ?? ''; ?>">
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Academic Information -->
            <div class="uk-width-1-1">
                <div class="uk-card uk-card-default uk-card-body">
                    <h3 class="uk-card-title">Academic Information</h3>
                    
                    <div class="uk-grid-small" uk-grid>
                        <div class="uk-width-1-3">
                            <label class="uk-form-label">Program *</label>
                            <select class="uk-select" name="program_id" required>
                                <?php
                                $programs = getAllPrograms();
                                foreach ($programs as $program) {
                                    $selected = $program['program_id'] == $selected_student['program_id'] ? 'selected' : '';
                                    echo "<option value='{$program['program_id']}' $selected>
                                        {$program['program_code']} - {$program['program_name']}
                                    </option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="uk-width-1-3">
                            <label class="uk-form-label">Year Level *</label>
                            <select class="uk-select" name="year_level" required>
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                <option value="<?php echo $i; ?>" 
                                    <?php echo $selected_student['year_level'] == $i ? 'selected' : ''; ?>>
                                    <?php echo $i; ?> Year
                                </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="uk-width-1-3">
                            <label class="uk-form-label">Student Type</label>
                            <select class="uk-select" name="student_type">
                                <option value="regular" <?php echo $selected_student['student_type'] == 'regular' ? 'selected' : ''; ?>>Regular</option>
                                <option value="irregular" <?php echo $selected_student['student_type'] == 'irregular' ? 'selected' : ''; ?>>Irregular</option>
                                <option value="transferee" <?php echo $selected_student['student_type'] == 'transferee' ? 'selected' : ''; ?>>Transferee</option>
                                <option value="shiftee" <?php echo $selected_student['student_type'] == 'shiftee' ? 'selected' : ''; ?>>Shiftee</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="uk-grid-small uk-margin-top" uk-grid>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Civil Status</label>
                            <select class="uk-select" name="civil_status">
                                <option value="single" <?php echo $selected_student['civil_status'] == 'single' ? 'selected' : ''; ?>>Single</option>
                                <option value="married" <?php echo $selected_student['civil_status'] == 'married' ? 'selected' : ''; ?>>Married</option>
                                <option value="widowed" <?php echo $selected_student['civil_status'] == 'widowed' ? 'selected' : ''; ?>>Widowed</option>
                                <option value="separated" <?php echo $selected_student['civil_status'] == 'separated' ? 'selected' : ''; ?>>Separated</option>
                            </select>
                        </div>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Nationality</label>
                            <input type="text" class="uk-input" name="nationality" 
                                   value="<?php echo $selected_student['nationality'] ?? 'Filipino'; ?>">
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Contact & Family Information -->
            <div class="uk-width-1-1">
                <div class="uk-card uk-card-default uk-card-body">
                    <h3 class="uk-card-title">Contact & Family Information</h3>
                    
                    <div class="uk-grid-small" uk-grid>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Present Address</label>
                            <textarea class="uk-textarea" name="present_address" rows="2"><?php echo $selected_student['present_address'] ?? ''; ?></textarea>
                        </div>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Permanent Address</label>
                            <textarea class="uk-textarea" name="permanent_address" rows="2"><?php echo $selected_student['permanent_address'] ?? ''; ?></textarea>
                        </div>
                    </div>
                    
                    <div class="uk-grid-small uk-margin-top" uk-grid>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Father's Name</label>
                            <input type="text" class="uk-input" name="father_name" 
                                   value="<?php echo $selected_student['father_name'] ?? ''; ?>">
                        </div>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Mother's Name</label>
                            <input type="text" class="uk-input" name="mother_name" 
                                   value="<?php echo $selected_student['mother_name'] ?? ''; ?>">
                        </div>
                    </div>
                    
                    <div class="uk-grid-small uk-margin-top" uk-grid>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Emergency Contact Name</label>
                            <input type="text" class="uk-input" name="emergency_contact_name" 
                                   value="<?php echo $selected_student['emergency_contact_name'] ?? ''; ?>">
                        </div>
                        <div class="uk-width-1-2">
                            <label class="uk-form-label">Emergency Contact Phone</label>
                            <input type="tel" class="uk-input" name="emergency_contact_phone" 
                                   value="<?php echo $selected_student['emergency_contact_phone'] ?? ''; ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="uk-margin-large-top">
            <button type="submit" class="uk-button uk-button-primary uk-button-large">
                <span uk-icon="icon: check"></span> Update Information
            </button>
            <a href="student-update.php" class="uk-button uk-button-default uk-button-large">
                <span uk-icon="icon: close"></span> Cancel
            </a>
        </div>
    </form>
    <?php elseif (isset($_GET['student_id']) && !$selected_student): ?>
    <div class="uk-alert-danger" uk-alert>
        <p>Student not found!</p>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ .'/../includes/footer.php'; ?>