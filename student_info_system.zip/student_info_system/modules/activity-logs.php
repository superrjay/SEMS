<?php
require_once __DIR__ .'/../includes/header.php';
require_once __DIR__ .'/../includes/functions.php';

// Date filter
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$module_filter = $_GET['module'] ?? 'all';
$user_filter = $_GET['user_id'] ?? 'all';

// Build query
$conn = getDBConnection();
$sql = "SELECT al.*, u.username, u.first_name, u.last_name 
        FROM activity_logs al 
        LEFT JOIN users u ON al.user_id = u.user_id 
        WHERE DATE(al.created_at) BETWEEN ? AND ?";

$params = [$start_date, $end_date];
$types = "ss";

if ($module_filter != 'all') {
    $sql .= " AND al.module = ?";
    $params[] = $module_filter;
    $types .= "s";
}

if ($user_filter != 'all') {
    $sql .= " AND al.user_id = ?";
    $params[] = $user_filter;
    $types .= "i";
}

$sql .= " ORDER BY al.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$activity_logs = [];
while ($row = $result->fetch_assoc()) {
    $activity_logs[] = $row;
}

$stmt->close();

// Get unique modules for filter
$modules_sql = "SELECT DISTINCT module FROM activity_logs ORDER BY module";
$modules_result = $conn->query($modules_sql);
$modules = [];
while ($row = $modules_result->fetch_assoc()) {
    $modules[] = $row['module'];
}

// Get users for filter
$users_sql = "SELECT user_id, username, CONCAT(first_name, ' ', last_name) as full_name 
              FROM users ORDER BY username";
$users_result = $conn->query($users_sql);
$users = [];
while ($row = $users_result->fetch_assoc()) {
    $users[] = $row;
}

$conn->close();
?>

<?php require_once __DIR__ .'/../includes/sidebar.php'; ?>

<div class="uk-container">
    <h1 class="uk-heading-divider">User Activity Logs & Audit Trail</h1>
    
    <!-- Filter Form -->
    <div class="uk-card uk-card-default uk-card-body uk-margin-bottom">
        <form method="GET" class="uk-form-stacked">
            <div class="uk-grid-small" uk-grid>
                <div class="uk-width-1-4@m">
                    <label class="uk-form-label">Start Date</label>
                    <input type="date" class="uk-input" name="start_date" value="<?php echo $start_date; ?>">
                </div>
                <div class="uk-width-1-4@m">
                    <label class="uk-form-label">End Date</label>
                    <input type="date" class="uk-input" name="end_date" value="<?php echo $end_date; ?>">
                </div>
                <div class="uk-width-1-4@m">
                    <label class="uk-form-label">Module</label>
                    <select class="uk-select" name="module">
                        <option value="all">All Modules</option>
                        <?php foreach ($modules as $module): ?>
                        <option value="<?php echo $module; ?>" 
                            <?php echo $module_filter == $module ? 'selected' : ''; ?>>
                            <?php echo ucfirst(str_replace('_', ' ', $module)); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="uk-width-1-4@m">
                    <label class="uk-form-label">User</label>
                    <select class="uk-select" name="user_id">
                        <option value="all">All Users</option>
                        <?php foreach ($users as $user): ?>
                        <option value="<?php echo $user['user_id']; ?>" 
                            <?php echo $user_filter == $user['user_id'] ? 'selected' : ''; ?>>
                            <?php echo $user['username']; ?> (<?php echo $user['full_name']; ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="uk-margin-top">
                <button type="submit" class="uk-button uk-button-primary">
                    <span uk-icon="filter"></span> Apply Filters
                </button>
                <a href="activity-logs.php" class="uk-button uk-button-default">
                    <span uk-icon="close"></span> Clear Filters
                </a>
            </div>
        </form>
    </div>
    
    <!-- Statistics -->
    <div class="uk-grid-match uk-grid-small uk-margin-bottom" uk-grid>
        <div class="uk-width-1-4@m">
            <div class="uk-card uk-card-primary uk-card-body">
                <h3 class="uk-card-title">Total Logs</h3>
                <p class="uk-text-large"><?php echo count($activity_logs); ?></p>
            </div>
        </div>
        
        <div class="uk-width-1-4@m">
            <div class="uk-card uk-card-secondary uk-card-body">
                <h3 class="uk-card-title">Unique Users</h3>
                <p class="uk-text-large">
                    <?php
                    $unique_users = array_unique(array_column($activity_logs, 'user_id'));
                    echo count($unique_users);
                    ?>
                </p>
            </div>
        </div>
        
        <div class="uk-width-1-4@m">
            <div class="uk-card uk-card-success uk-card-body">
                <h3 class="uk-card-title">Modules</h3>
                <p class="uk-text-large">
                    <?php
                    $unique_modules = array_unique(array_column($activity_logs, 'module'));
                    echo count($unique_modules);
                    ?>
                </p>
            </div>
        </div>
        
        <div class="uk-width-1-4@m">
            <div class="uk-card uk-card-danger uk-card-body">
                <h3 class="uk-card-title">Date Range</h3>
                <p class="uk-text-small">
                    <?php echo date('M d, Y', strtotime($start_date)); ?> to 
                    <?php echo date('M d, Y', strtotime($end_date)); ?>
                </p>
            </div>
        </div>
    </div>
    
    <!-- Activity Logs Table -->
    <div class="uk-card uk-card-default uk-card-body">
        <div class="uk-overflow-auto">
            <table class="uk-table uk-table-divider uk-table-hover uk-table-small">
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Module</th>
                        <th>Description</th>
                        <th>Record ID</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($activity_logs as $log): ?>
                    <tr>
                        <td>
                            <small>
                                <?php echo date('Y-m-d', strtotime($log['created_at'])); ?><br>
                                <?php echo date('H:i:s', strtotime($log['created_at'])); ?>
                            </small>
                        </td>
                        <td>
                            <?php if ($log['username']): ?>
                            <strong><?php echo $log['username']; ?></strong><br>
                            <small class="uk-text-meta"><?php echo $log['first_name'] . ' ' . $log['last_name']; ?></small>
                            <?php else: ?>
                            <span class="uk-text-meta">System</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="uk-label uk-label-<?php 
                                echo strpos($log['action'], 'delete') !== false ? 'danger' : 
                                     (strpos($log['action'], 'create') !== false ? 'success' : 
                                     (strpos($log['action'], 'update') !== false ? 'warning' : 'primary')); 
                            ?>">
                                <?php echo ucfirst($log['action']); ?>
                            </span>
                        </td>
                        <td>
                            <span class="uk-badge"><?php echo $log['module']; ?></span>
                        </td>
                        <td>
                            <?php echo $log['description']; ?>
                            <?php if (!$log['description']): ?>
                            <span class="uk-text-meta">N/A</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($log['record_id']): ?>
                            <code>#<?php echo $log['record_id']; ?></code>
                            <?php else: ?>
                            <span class="uk-text-meta">N/A</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <code><?php echo $log['ip_address']; ?></code>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <?php if (empty($activity_logs)): ?>
        <div class="uk-text-center uk-padding">
            <p class="uk-text-large">No activity logs found for the selected filters.</p>
        </div>
        <?php endif; ?>
        
        <!-- Export Options -->
        <div class="uk-margin-top">
            <div class="uk-button-group">
                <button class="uk-button uk-button-default" onclick="exportLogs('csv')">
                    <span uk-icon="download"></span> Export as CSV
                </button>
                <button class="uk-button uk-button-default" onclick="exportLogs('pdf')">
                    <span uk-icon="file-pdf"></span> Export as PDF
                </button>
                <button class="uk-button uk-button-default" onclick="printLogs()">
                    <span uk-icon="print"></span> Print Logs
                </button>
            </div>
        </div>
    </div>
    
    <!-- Module Activity Summary -->
    <div class="uk-card uk-card-default uk-card-body uk-margin-top">
        <h3>Module Activity Summary</h3>
        <div class="uk-grid-small" uk-grid>
            <?php
            // Group logs by module
            $module_summary = [];
            foreach ($activity_logs as $log) {
                $module = $log['module'];
                if (!isset($module_summary[$module])) {
                    $module_summary[$module] = 0;
                }
                $module_summary[$module]++;
            }
            
            arsort($module_summary);
            
            foreach ($module_summary as $module => $count):
                $percentage = count($activity_logs) > 0 ? ($count / count($activity_logs)) * 100 : 0;
            ?>
            <div class="uk-width-1-4@m">
                <div class="uk-card uk-card-secondary uk-card-body uk-card-small">
                    <h4 class="uk-card-title uk-margin-remove"><?php echo ucfirst(str_replace('_', ' ', $module)); ?></h4>
                    <p class="uk-text-large uk-margin-remove"><?php echo $count; ?></p>
                    <progress class="uk-progress" value="<?php echo $percentage; ?>" max="100"></progress>
                    <small class="uk-text-meta"><?php echo round($percentage, 1); ?>% of total</small>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
function exportLogs(format) {
    UIkit.notification({
        message: `Exporting logs as ${format.toUpperCase()}...`,
        status: 'success'
    });
    
    // In a real implementation, this would make an AJAX call to generate the export file
    setTimeout(() => {
        UIkit.notification({
            message: 'Export completed successfully!',
            status: 'success'
        });
    }, 1000);
}

function printLogs() {
    window.print();
}
</script>

<?php require_once __DIR__ .'/../includes/footer.php'; ?>