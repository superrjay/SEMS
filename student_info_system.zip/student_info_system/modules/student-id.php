<?php
require_once __DIR__ .'/../includes/header.php';
require_once __DIR__ .'/../includes/functions.php';

$student = null;
$id_card_data = null;

// Search student for ID generation
if (isset($_GET['search_id'])) {
    $conn = getDBConnection();
    $search_term = "%{$_GET['id_search']}%";
    
    $sql = "SELECT s.*, p.program_name, p.program_code, spi.* 
            FROM students s 
            LEFT JOIN programs p ON s.program_id = p.program_id 
            LEFT JOIN student_personal_info spi ON s.student_id = spi.student_id 
            WHERE s.student_number LIKE ? 
               OR CONCAT(s.first_name, ' ', s.last_name) LIKE ?
            LIMIT 1";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $search_term, $search_term);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
        $id_card_data = $student;
        
        // Log activity
        logActivity($_SESSION['user_id'], 'view', 'student_id', 
                    "Generated ID card for student: {$student['student_number']}", 
                    $student['student_id']);
    }
    
    $stmt->close();
    $conn->close();
}

// Generate ID Card
if (isset($_POST['generate_id_card'])) {
    // In a real system, you would generate a PDF or image here
    // For this example, we'll just show a preview
    
    $student_id = $_POST['student_id'];
    $student = getStudentById($student_id);
    
    // Log activity
    logActivity($_SESSION['user_id'], 'generate', 'student_id', 
                "Generated printable ID card for student: {$student['student_number']}", 
                $student_id);
    
    echo "<script>UIkit.notification({message: 'ID Card generated successfully!', status: 'success'})</script>";
}
?>

<?php require_once __DIR__ .'/../includes/sidebar.php'; ?>

<div class="uk-container">
    <h1 class="uk-heading-divider">Student ID Generation</h1>
    
    <!-- Search Form -->
    <div class="uk-card uk-card-default uk-card-body uk-margin-bottom">
        <form method="GET" class="uk-form-stacked">
            <div class="uk-grid-small" uk-grid>
                <div class="uk-width-3-4@m">
                    <input type="text" class="uk-input" name="id_search" 
                           placeholder="Enter Student Number or Full Name"
                           value="<?php echo $_GET['id_search'] ?? ''; ?>" required>
                </div>
                <div class="uk-width-1-4@m">
                    <button type="submit" name="search_id" class="uk-button uk-button-primary uk-width-1-1">
                        <span uk-icon="search"></span> Search Student
                    </button>
                </div>
            </div>
        </form>
    </div>
    
    <?php if ($student): ?>
    <!-- ID Card Preview -->
    <div class="uk-card uk-card-default uk-card-body uk-margin-bottom">
        <h3>ID Card Preview</h3>
        
        <div class="uk-grid-match" uk-grid>
            <div class="uk-width-1-3@m">
                <!-- ID Card Design -->
                <div class="id-card-template uk-card uk-card-primary uk-card-body">
                    <div class="uk-text-center">
                        <div class="uk-border-circle uk-background-light uk-padding uk-margin-auto uk-margin-bottom" 
                             style="width: 120px; height: 120px;">
                            <span uk-icon="icon: user; ratio: 3"></span>
                        </div>
                        
                        <h3 class="uk-card-title uk-margin-remove"><?php echo strtoupper($student['first_name'] . ' ' . $student['last_name']); ?></h3>
                        <p class="uk-text-meta uk-margin-remove"><?php echo $student['student_number']; ?></p>
                        
                        <hr class="uk-divider-small">
                        
                        <div class="uk-text-left uk-margin-top">
                            <p class="uk-margin-small">
                                <strong>Program:</strong><br>
                                <?php echo $student['program_code']; ?>
                            </p>
                            <p class="uk-margin-small">
                                <strong>Year Level:</strong><br>
                                <?php echo $student['year_level']; ?>
                            </p>
                            <p class="uk-margin-small">
                                <strong>Valid Until:</strong><br>
                                <?php echo date('Y') + 1; ?>-<?php echo date('Y') + 2; ?>
                            </p>
                        </div>
                        
                        <div class="uk-margin-top">
                            <div class="uk-inline">
                                <!-- QR Code placeholder -->
                                <div class="uk-background-white uk-padding-small">
                                    <span uk-icon="icon: qrcode; ratio: 2"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <style>
                .id-card-template {
                    width: 350px;
                    height: 500px;
                    border-radius: 15px;
                    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
                }
                </style>
            </div>
            
            <div class="uk-width-2-3@m">
                <!-- Student Information -->
                <div class="uk-card uk-card-secondary uk-card-body">
                    <h3>Student Information</h3>
                    
                    <div class="uk-grid-small" uk-grid>
                        <div class="uk-width-1-2">
                            <p><strong>Full Name:</strong><br>
                            <?php echo "{$student['first_name']} {$student['middle_name']} {$student['last_name']}"; ?></p>
                            
                            <p><strong>Date of Birth:</strong><br>
                            <?php echo date('F d, Y', strtotime($student['date_of_birth'])); ?></p>
                            
                            <p><strong>Gender:</strong><br>
                            <?php echo ucfirst($student['gender']); ?></p>
                            
                            <p><strong>Contact:</strong><br>
                            <?php echo $student['email']; ?><br>
                            <?php echo $student['phone'] ?? 'N/A'; ?></p>
                        </div>
                        
                        <div class="uk-width-1-2">
                            <p><strong>Program:</strong><br>
                            <?php echo $student['program_name']; ?></p>
                            
                            <p><strong>Year Level:</strong><br>
                            <?php echo $student['year_level']; ?></p>
                            
                            <p><strong>Status:</strong><br>
                            <span class="uk-label uk-label-<?php 
                                echo $student['status'] == 'active' ? 'success' : 
                                     ($student['status'] == 'graduated' ? 'primary' : 'warning'); 
                            ?>">
                                <?php echo ucfirst($student['status']); ?>
                            </span></p>
                            
                            <p><strong>Admission Date:</strong><br>
                            <?php echo date('F d, Y', strtotime($student['admission_date'])); ?></p>
                        </div>
                    </div>
                    
                    <!-- ID Card Actions -->
                    <div class="uk-margin-top">
                        <form method="POST">
                            <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">
                            
                            <div class="uk-button-group">
                                <button type="submit" name="generate_id_card" class="uk-button uk-button-primary">
                                    <span uk-icon="icon: print"></span> Generate & Print ID
                                </button>
                                <button type="button" class="uk-button uk-button-default" onclick="downloadIDCard()">
                                    <span uk-icon="icon: download"></span> Download ID
                                </button>
                                <button type="button" class="uk-button uk-button-secondary" onclick="generateQRCode()">
                                    <span uk-icon="icon: qrcode"></span> Generate QR Code
                                </button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- QR Code Display -->
                    <div id="qrCodeContainer" class="uk-margin-top" style="display: none;">
                        <div class="uk-card uk-card-body uk-card-default">
                            <h4>Student QR Code</h4>
                            <div id="qrCodeImage" class="uk-text-center"></div>
                            <p class="uk-text-meta">Scan this QR code to verify student information</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- ID Card History -->
    <div class="uk-card uk-card-default uk-card-body">
        <h3>ID Card Generation History</h3>
        
        <table class="uk-table uk-table-divider uk-table-small">
            <thead>
                <tr>
                    <th>Generated Date</th>
                    <th>Generated By</th>
                    <th>Purpose</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $conn = getDBConnection();
                $sql = "SELECT al.*, u.username 
                        FROM activity_logs al 
                        LEFT JOIN users u ON al.user_id = u.user_id 
                        WHERE al.module = 'student_id' 
                          AND al.record_id = ?
                        ORDER BY al.created_at DESC 
                        LIMIT 5";
                
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $student['student_id']);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . date('M d, Y H:i', strtotime($row['created_at'])) . "</td>";
                        echo "<td>" . $row['username'] . "</td>";
                        echo "<td>" . ucfirst(str_replace('_', ' ', $row['action'])) . "</td>";
                        echo "<td><span class='uk-label uk-label-success'>Completed</span></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4' class='uk-text-center'>No ID generation history</td></tr>";
                }
                
                $stmt->close();
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
    
    <?php elseif (isset($_GET['search_id'])): ?>
    <div class="uk-alert-danger" uk-alert>
        <p>Student not found. Please check the student number or name and try again.</p>
    </div>
    <?php endif; ?>
</div>

<script>
function downloadIDCard() {
    UIkit.notification({
        message: 'ID Card download started...',
        status: 'success'
    });
    // In a real implementation, this would generate and download a PDF
}

function generateQRCode() {
    const qrContainer = document.getElementById('qrCodeContainer');
    const qrImage = document.getElementById('qrCodeImage');
    
    // Generate a simple QR code placeholder
    qrImage.innerHTML = `
        <div class="uk-background-white uk-padding-large uk-inline">
            <span uk-icon="icon: qrcode; ratio: 4"></span>
            <div class="uk-overlay uk-overlay-default uk-position-bottom">
                <p class="uk-text-small">Student: <?php echo $student['student_number'] ?? ''; ?></p>
            </div>
        </div>
    `;
    
    qrContainer.style.display = 'block';
    
    // Scroll to QR code
    UIkit.util.scrollIntoView(qrContainer, { offset: 100 });
    
    UIkit.notification({
        message: 'QR Code generated successfully!',
        status: 'success'
    });
}
</script>

<?php require_once __DIR__ .'/../includes/footer.php'; ?>