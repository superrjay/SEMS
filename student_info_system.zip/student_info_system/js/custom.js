// Student Information System Custom JavaScript

document.addEventListener('DOMContentLoaded', function() {
    
    // Initialize UIkit components
    if (typeof UIkit !== 'undefined') {
        UIkit.notification({
            message: 'System loaded successfully!',
            status: 'success',
            pos: 'top-right',
            timeout: 2000
        });
    }
    
    // Form validation enhancement
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const requiredFields = this.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.classList.add('uk-form-danger');
                    isValid = false;
                    
                    // Show error message
                    let errorMsg = field.nextElementSibling;
                    if (!errorMsg || !errorMsg.classList.contains('validation-error')) {
                        errorMsg = document.createElement('div');
                        errorMsg.className = 'validation-error';
                        errorMsg.textContent = 'This field is required';
                        field.parentNode.appendChild(errorMsg);
                    }
                } else {
                    field.classList.remove('uk-form-danger');
                    const errorMsg = field.nextElementSibling;
                    if (errorMsg && errorMsg.classList.contains('validation-error')) {
                        errorMsg.remove();
                    }
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                UIkit.notification({
                    message: 'Please fill in all required fields',
                    status: 'danger'
                });
            }
        });
    });
    
    // Auto-hide notifications after 5 seconds
    const notifications = document.querySelectorAll('.uk-notification');
    notifications.forEach(notification => {
        setTimeout(() => {
            if (notification.parentNode) {
                UIkit.notification(notification).close();
            }
        }, 5000);
    });
    
    // Search enhancement
    const searchInputs = document.querySelectorAll('input[type="search"], input[name*="search"]');
    searchInputs.forEach(input => {
        let debounceTimer;
        input.addEventListener('input', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                if (this.value.length >= 3) {
                    // In a real application, this would trigger AJAX search
                    console.log('Searching for:', this.value);
                }
            }, 300);
        });
    });
    
    // Date picker enhancement
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        // Set max date to today for date of birth
        if (input.name === 'date_of_birth') {
            const today = new Date().toISOString().split('T')[0];
            input.max = today;
        }
        
        // Add clear button
        const clearBtn = document.createElement('button');
        clearBtn.type = 'button';
        clearBtn.className = 'uk-button uk-button-default uk-button-small';
        clearBtn.innerHTML = '<span uk-icon="icon: close"></span>';
        clearBtn.style.marginLeft = '5px';
        clearBtn.addEventListener('click', () => {
            input.value = '';
        });
        
        input.parentNode.appendChild(clearBtn);
    });
    
    // Table row click for mobile
    if (window.innerWidth < 768) {
        const tableRows = document.querySelectorAll('tbody tr');
        tableRows.forEach(row => {
            row.addEventListener('click', function(e) {
                if (!e.target.closest('a, button')) {
                    this.classList.toggle('uk-active');
                }
            });
        });
    }
    
    // Copy student number to clipboard
    const copyButtons = document.querySelectorAll('.copy-student-number');
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const studentNumber = this.getAttribute('data-number');
            navigator.clipboard.writeText(studentNumber).then(() => {
                UIkit.notification({
                    message: 'Student number copied to clipboard!',
                    status: 'success'
                });
            });
        });
    });
    
    // Auto-generate email from name
    const nameInputs = document.querySelectorAll('input[name="first_name"], input[name="last_name"]');
    const emailInput = document.querySelector('input[name="email"]');
    
    if (emailInput && nameInputs.length >= 2) {
        let firstNameInput, lastNameInput;
        
        nameInputs.forEach(input => {
            if (input.name === 'first_name') firstNameInput = input;
            if (input.name === 'last_name') lastNameInput = input;
            
            input.addEventListener('blur', generateEmail);
        });
        
        function generateEmail() {
            if (firstNameInput && lastNameInput && firstNameInput.value && lastNameInput.value && !emailInput.value) {
                const firstName = firstNameInput.value.toLowerCase().replace(/\s+/g, '');
                const lastName = lastNameInput.value.toLowerCase().replace(/\s+/g, '');
                const suggestedEmail = `${firstName}.${lastName}@student.edu`;
                emailInput.value = suggestedEmail;
            }
        }
    }
    
    // Export functionality
    window.exportData = function(format) {
        const table = document.querySelector('table');
        if (!table) return;
        
        let data = [];
        const headers = [];
        table.querySelectorAll('thead th').forEach(th => {
            headers.push(th.textContent.trim());
        });
        
        table.querySelectorAll('tbody tr').forEach(row => {
            const rowData = [];
            row.querySelectorAll('td').forEach(cell => {
                rowData.push(cell.textContent.trim());
            });
            data.push(rowData);
        });
        
        if (format === 'csv') {
            exportToCSV(headers, data);
        } else if (format === 'json') {
            exportToJSON(headers, data);
        }
    };
    
    function exportToCSV(headers, data) {
        const csvContent = [
            headers.join(','),
            ...data.map(row => row.join(','))
        ].join('\n');
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        
        link.setAttribute('href', url);
        link.setAttribute('download', `student_data_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    function exportToJSON(headers, data) {
        const jsonData = data.map(row => {
            const obj = {};
            headers.forEach((header, index) => {
                obj[header] = row[index];
            });
            return obj;
        });
        
        const blob = new Blob([JSON.stringify(jsonData, null, 2)], { type: 'application/json' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        
        link.setAttribute('href', url);
        link.setAttribute('download', `student_data_${new Date().toISOString().split('T')[0]}.json`);
        link.style.visibility = 'hidden';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    // Print functionality
    window.printPage = function() {
        window.print();
    };
    
    // Initialize tooltips
    if (typeof UIkit !== 'undefined') {
        UIkit.util.on(document, 'mouseenter', '[uk-tooltip]', function(e) {
            const el = e.target;
            if (el.hasAttribute('uk-tooltip')) {
                const tooltip = UIkit.tooltip(el);
                if (tooltip) {
                    tooltip.show();
                }
            }
        });
    }
    
    // Auto-save form data
    const autoSaveForms = document.querySelectorAll('.auto-save');
    autoSaveForms.forEach(form => {
        let saveTimer;
        
        form.addEventListener('input', function() {
            clearTimeout(saveTimer);
            saveTimer = setTimeout(() => {
                const formData = new FormData(this);
                const data = {};
                formData.forEach((value, key) => {
                    data[key] = value;
                });
                
                // Save to localStorage
                localStorage.setItem('form_autosave_' + this.id, JSON.stringify(data));
                
                UIkit.notification({
                    message: 'Progress saved locally',
                    status: 'success',
                    timeout: 1000
                });
            }, 2000);
        });
        
        // Load saved data
        const savedData = localStorage.getItem('form_autosave_' + form.id);
        if (savedData) {
            const data = JSON.parse(savedData);
            Object.keys(data).forEach(key => {
                const input = form.querySelector(`[name="${key}"]`);
                if (input && !input.value) {
                    input.value = data[key];
                }
            });
        }
    });
    
    // Responsive table toggle
    const viewToggle = document.createElement('div');
    viewToggle.className = 'uk-button-group uk-margin-small';
    viewToggle.innerHTML = `
        <button class="uk-button uk-button-default uk-button-small" id="tableView">
            <span uk-icon="icon: table"></span> Table
        </button>
        <button class="uk-button uk-button-default uk-button-small" id="cardView">
            <span uk-icon="icon: grid"></span> Cards
        </button>
    `;
    
    const tables = document.querySelectorAll('.uk-overflow-auto');
    tables.forEach(tableContainer => {
        const parent = tableContainer.parentNode;
        if (!parent.querySelector('.uk-button-group')) {
            parent.insertBefore(viewToggle.cloneNode(true), tableContainer);
        }
    });
    
    // View toggle functionality
    document.addEventListener('click', function(e) {
        if (e.target.id === 'tableView' || e.target.closest('#tableView')) {
            const tableContainer = e.target.closest('.uk-card-body').querySelector('.uk-overflow-auto');
            tableContainer.style.display = 'block';
            
            // Hide card view if exists
            const cardView = tableContainer.nextElementSibling;
            if (cardView && cardView.classList.contains('card-view')) {
                cardView.style.display = 'none';
            }
        }
        
        if (e.target.id === 'cardView' || e.target.closest('#cardView')) {
            const tableContainer = e.target.closest('.uk-card-body').querySelector('.uk-overflow-auto');
            tableContainer.style.display = 'none';
            
            // Create or show card view
            let cardView = tableContainer.nextElementSibling;
            if (!cardView || !cardView.classList.contains('card-view')) {
                cardView = document.createElement('div');
                cardView.className = 'card-view uk-grid-small uk-child-width-1-2@s uk-child-width-1-3@m uk-child-width-1-4@l uk-grid-match';
                cardView.style.marginTop = '20px';
                
                const table = tableContainer.querySelector('table');
                if (table) {
                    const rows = table.querySelectorAll('tbody tr');
                    rows.forEach(row => {
                        const cells = row.querySelectorAll('td');
                        if (cells.length > 0) {
                            const card = document.createElement('div');
                            card.className = 'uk-card uk-card-default uk-card-body';
                            card.innerHTML = `
                                <h4 class="uk-card-title">${cells[1]?.textContent || 'Student'}</h4>
                                <p>${cells[0]?.textContent || 'No data'}</p>
                            `;
                            cardView.appendChild(card);
                        }
                    });
                }
                
                tableContainer.parentNode.insertBefore(cardView, tableContainer.nextSibling);
            } else {
                cardView.style.display = 'grid';
            }
        }
    });
});