// Client-side routing utilities
class ClientRouter {
    constructor() {
        this.basePath = '/student_info_system';
        this.init();
    }
    
    init() {
        // Handle link clicks for AJAX navigation
        document.addEventListener('click', (e) => {
            const link = e.target.closest('a[data-ajax]');
            if (link) {
                e.preventDefault();
                this.navigate(link.href, true);
            }
        });
        
        // Handle browser back/forward buttons
        window.addEventListener('popstate', (e) => {
            if (e.state && e.state.url) {
                this.navigate(e.state.url, false, false);
            }
        });
    }
    
    navigate(url, pushState = true, ajax = true) {
        if (ajax) {
            this.loadPage(url, pushState);
        } else {
            window.location.href = url;
        }
    }
    
    async loadPage(url, pushState) {
        try {
            // Show loading indicator
            this.showLoading();
            
            // Fetch the page content
            const response = await fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const html = await response.text();
            
            // Parse the HTML
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            
            // Update page title
            document.title = doc.title;
            
            // Update main content
            const mainContent = doc.querySelector('.uk-container');
            if (mainContent) {
                document.querySelector('.uk-container').outerHTML = mainContent.outerHTML;
            }
            
            // Update browser history
            if (pushState) {
                history.pushState({ url: url }, '', url);
            }
            
            // Reinitialize UIkit components
            if (typeof UIkit !== 'undefined') {
                UIkit.update();
            }
            
            // Hide loading indicator
            this.hideLoading();
            
            // Scroll to top
            window.scrollTo(0, 0);
            
        } catch (error) {
            console.error('Error loading page:', error);
            this.hideLoading();
            
            // Fallback to full page load
            window.location.href = url;
        }
    }
    
    showLoading() {
        let loader = document.getElementById('page-loader');
        if (!loader) {
            loader = document.createElement('div');
            loader.id = 'page-loader';
            loader.className = 'page-loader';
            loader.innerHTML = `
                <div class="loading-spinner">
                    <div uk-spinner="ratio: 2"></div>
                    <p>Loading...</p>
                </div>
            `;
            document.body.appendChild(loader);
            
            // Add styles
            const style = document.createElement('style');
            style.textContent = `
                .page-loader {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(255, 255, 255, 0.9);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    z-index: 9999;
                }
                .loading-spinner {
                    text-align: center;
                }
                .loading-spinner p {
                    margin-top: 10px;
                    color: #333;
                }
            `;
            document.head.appendChild(style);
        }
        loader.style.display = 'flex';
    }
    
    hideLoading() {
        const loader = document.getElementById('page-loader');
        if (loader) {
            loader.style.display = 'none';
        }
    }
    
    // API request helper
    async apiRequest(endpoint, method = 'GET', data = null) {
        const url = `${this.basePath}/api${endpoint}`;
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        };
        
        if (data) {
            options.body = JSON.stringify(data);
        }
        
        try {
            const response = await fetch(url, options);
            return await response.json();
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    }
}

// Initialize client router when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.appRouter = new ClientRouter();
    
    // Add active class to current route in sidebar
    const currentPath = window.location.pathname;
    const sidebarLinks = document.querySelectorAll('.sidebar a');
    
    sidebarLinks.forEach(link => {
        const linkPath = new URL(link.href).pathname;
        if (linkPath === currentPath || 
            (currentPath.includes(linkPath) && linkPath !== '/')) {
            link.parentElement.classList.add('route-active');
        }
    });
    
    // Add AJAX navigation to links (optional)
    const mainLinks = document.querySelectorAll('a:not([data-no-ajax])');
    mainLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href && href.startsWith('/') && !href.startsWith('//') && 
            !href.includes('#') && !href.includes('?')) {
            link.setAttribute('data-ajax', 'true');
        }
    });
});

// Global helper functions
function navigateTo(url, ajax = true) {
    if (window.appRouter) {
        window.appRouter.navigate(url, true, ajax);
    } else {
        window.location.href = url;
    }
}

function apiRequest(endpoint, method = 'GET', data = null) {
    if (window.appRouter) {
        return window.appRouter.apiRequest(endpoint, method, data);
    }
    throw new Error('Router not initialized');
}