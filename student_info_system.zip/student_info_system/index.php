<?php
// index.php - Main entry point with routing
session_start();

// For demo purposes, set a default session if not exists
if (!isset($_SESSION['username'])) {
    $_SESSION['username'] = 'admin';
    $_SESSION['user_id'] = 1;
    $_SESSION['role'] = 'Administrator';
}

// Include the router
require_once __DIR__ . '/routes.php';

// Dispatch the request
$router->dispatch();
