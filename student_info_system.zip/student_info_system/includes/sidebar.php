<?php
// Get base URL from router
global $router;
$baseUrl = isset($router) ? $router->getBaseUrl() : '';
?>
<div class="uk-flex">
    <!-- Sidebar -->
    <div class="uk-width-1-4@m uk-width-1-5@l uk-padding-small sidebar">
        <div class="uk-card uk-card-default uk-card-body uk-padding-small">
            <h3 class="uk-card-title">Student Information System</h3>
            <p class="uk-text-meta">Welcome, <?php echo $_SESSION['username'] ?? 'User'; ?></p>
            
            <ul class="uk-nav uk-nav-default uk-margin-top">
                <li class="uk-nav-header">Main Menu</li>
                <li><a href="<?php echo $baseUrl; ?>/"><span class="uk-margin-small-right" uk-icon="home"></span> Dashboard</a></li>
                
                <li class="uk-nav-divider"></li>
                <li class="uk-nav-header">Student Management</li>
                <li><a href="<?php echo $baseUrl; ?>/student/register"><span class="uk-margin-small-right" uk-icon="plus"></span> Student Registration</a></li>
                <li><a href="<?php echo $baseUrl; ?>/student/update"><span class="uk-margin-small-right" uk-icon="pencil"></span> Update Information</a></li>
                <li><a href="<?php echo $baseUrl; ?>/student/search"><span class="uk-margin-small-right" uk-icon="search"></span> Search Students</a></li>
                
                <li class="uk-nav-divider"></li>
                <li class="uk-nav-header">Academic & ID</li>
                <li><a href="<?php echo $baseUrl; ?>/academic/records"><span class="uk-margin-small-right" uk-icon="book"></span> Academic Records</a></li>
                <li><a href="<?php echo $baseUrl; ?>/student/id/generate"><span class="uk-margin-small-right" uk-icon="credit-card"></span> Student ID</a></li>
                <li><a href="<?php echo $baseUrl; ?>/status/tracking"><span class="uk-margin-small-right" uk-icon="users"></span> Status Tracking</a></li>
                
                <li class="uk-nav-divider"></li>
                <li class="uk-nav-header">System</li>
                <li><a href="<?php echo $baseUrl; ?>/activity/logs"><span class="uk-margin-small-right" uk-icon="list"></span> Activity Logs</a></li>
                <li><a href="<?php echo $baseUrl; ?>/reports"><span class="uk-margin-small-right" uk-icon="print"></span> Reports</a></li>
            </ul>
            
            <!-- Current User Info -->
            <div class="uk-margin-top uk-padding-small uk-background-muted">
                <p class="uk-text-small uk-margin-remove">
                    <strong>User:</strong> <?php echo $_SESSION['username'] ?? 'Guest'; ?><br>
                    <strong>Role:</strong> <?php echo $_SESSION['role'] ?? 'N/A'; ?><br>
                    <strong>Time:</strong> <?php echo date('h:i A'); ?>
                </p>
            </div>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="uk-width-3-4@m uk-width-4-5@l uk-padding">
