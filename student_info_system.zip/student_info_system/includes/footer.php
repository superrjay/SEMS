    </div> <!-- Close main content div from sidebar.php -->
</div> <!-- Close flex div from sidebar.php -->

<!-- UIkit JS -->
<script src="https://cdn.jsdelivr.net/npm/uikit@3.16.22/dist/js/uikit.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/uikit@3.16.22/dist/js/uikit-icons.min.js"></script>

<!-- Routing JS -->
<script src="<?php echo $basePath; ?>/js/routing.js"></script>

<!-- Custom JS -->
<script src="<?php echo $basePath; ?>/js/custom.js"></script>

</body>
</html>