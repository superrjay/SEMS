<?php
require_once __DIR__ . '/../config/database.php';

// Function to log activities
function logActivity($user_id, $action, $module, $description = '', $record_id = null) {
    $conn = getDBConnection();
    
    $sql = "INSERT INTO activity_logs (user_id, action, module, record_id, description, ip_address, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())";
    
    $stmt = $conn->prepare($sql);
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    
    $stmt->bind_param("ississ", $user_id, $action, $module, $record_id, $description, $ip_address);
    $stmt->execute();
    $stmt->close();
    $conn->close();
}

// Function to generate student number
function generateStudentNumber($program_code, $year) {
    $conn = getDBConnection();
    
    // Get last student number for this year
    $sql = "SELECT MAX(student_number) as last_number FROM students 
            WHERE student_number LIKE '{$program_code}-{$year}%'";
    $result = $conn->query($sql);
    
    $new_number = 1;
    if ($row = $result->fetch_assoc()) {
        if ($row['last_number']) {
            $parts = explode('-', $row['last_number']);
            $last_seq = intval(end($parts));
            $new_number = $last_seq + 1;
        }
    }
    
    // Format: BSCS-2026-001
    $student_number = sprintf("%s-%s-%03d", $program_code, $year, $new_number);
    
    $conn->close();
    return $student_number;
}

// Function to get student by ID
function getStudentById($student_id) {
    $conn = getDBConnection();
    
    $sql = "SELECT s.*, p.program_name, p.program_code 
            FROM students s 
            LEFT JOIN programs p ON s.program_id = p.program_id 
            WHERE s.student_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
    
    $stmt->close();
    $conn->close();
    
    return $student;
}

// Function to get all programs
function getAllPrograms() {
    $conn = getDBConnection();
    
    $sql = "SELECT * FROM programs WHERE status = 'active' ORDER BY program_name";
    $result = $conn->query($sql);
    
    $programs = [];
    while ($row = $result->fetch_assoc()) {
        $programs[] = $row;
    }
    
    $conn->close();
    return $programs;
}

// Function to update student status
function updateStudentStatus($student_id, $new_status, $reason = '', $changed_by = 1) {
    $conn = getDBConnection();
    
    // Get current status
    $current_sql = "SELECT status FROM students WHERE student_id = ?";
    $stmt = $conn->prepare($current_sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
    $previous_status = $student['status'];
    $stmt->close();
    
    // Update student status
    $update_sql = "UPDATE students SET status = ? WHERE student_id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("si", $new_status, $student_id);
    $stmt->execute();
    $stmt->close();
    
    // Log status change
    $history_sql = "INSERT INTO student_status_history 
                    (student_id, previous_status, new_status, reason, changed_by) 
                    VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($history_sql);
    $stmt->bind_param("isssi", $student_id, $previous_status, $new_status, $reason, $changed_by);
    $stmt->execute();
    $stmt->close();
    
    $conn->close();
    
    // Log activity
    logActivity($changed_by, 'update', 'student_status', 
                "Changed status from $previous_status to $new_status for student ID: $student_id", 
                $student_id);
    
    return true;
}
?>