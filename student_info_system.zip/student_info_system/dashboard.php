<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/functions.php';

// Get dashboard statistics
$conn = getDBConnection();

// Total students
$total_sql = "SELECT COUNT(*) as total FROM students";
$total_result = $conn->query($total_sql);
$total_students = $total_result->fetch_assoc()['total'];

// Active students
$active_sql = "SELECT COUNT(*) as active FROM students WHERE status = 'active'";
$active_result = $conn->query($active_sql);
$active_students = $active_result->fetch_assoc()['active'];

// Total programs
$programs_sql = "SELECT COUNT(*) as total FROM programs WHERE status = 'active'";
$programs_result = $conn->query($programs_sql);
$total_programs = $programs_result->fetch_assoc()['total'];

// Recent registrations (last 7 days)
$recent_sql = "SELECT COUNT(*) as recent FROM students 
               WHERE admission_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
$recent_result = $conn->query($recent_sql);
$recent_students = $recent_result->fetch_assoc()['recent'];

// Students by status
$status_sql = "SELECT status, COUNT(*) as count FROM students GROUP BY status";
$status_result = $conn->query($status_sql);
$status_data = [];
while ($row = $status_result->fetch_assoc()) {
    $status_data[$row['status']] = $row['count'];
}

// Students by year level
$year_sql = "SELECT year_level, COUNT(*) as count FROM students 
             WHERE status = 'active' GROUP BY year_level ORDER BY year_level";
$year_result = $conn->query($year_sql);
$year_data = [];
while ($row = $year_result->fetch_assoc()) {
    $year_data[$row['year_level']] = $row['count'];
}

// Recent activity logs
$logs_sql = "SELECT al.*, u.username 
             FROM activity_logs al 
             LEFT JOIN users u ON al.user_id = u.user_id 
             ORDER BY al.created_at DESC LIMIT 10";
$logs_result = $conn->query($logs_sql);
$recent_logs = [];
while ($row = $logs_result->fetch_assoc()) {
    $recent_logs[] = $row;
}

$conn->close();

// Get base URL for links
global $router;
$baseUrl = isset($router) ? $router->getBaseUrl() : '';
?>

<?php require_once __DIR__ . '/includes/sidebar.php'; ?>

<div class="uk-container">
    <h1 class="uk-heading-divider">Dashboard</h1>
    <p class="uk-text-lead">Welcome to the Student Information System</p>
    
    <!-- Statistics Cards -->
    <div class="uk-grid-match uk-grid-small uk-margin-bottom" uk-grid>
        <div class="uk-width-1-4@m">
            <div class="uk-card uk-card-primary uk-card-body">
                <div class="uk-flex uk-flex-between uk-flex-middle">
                    <div>
                        <h3 class="uk-card-title uk-margin-remove"><?php echo $total_students; ?></h3>
                        <p class="uk-text-meta uk-margin-remove">Total Students</p>
                    </div>
                    <span uk-icon="icon: users; ratio: 2.5"></span>
                </div>
            </div>
        </div>
        
        
        <div class="uk-width-1-4@m">
            <div class="uk-card uk-card-success uk-card-body">
                <div class="uk-flex uk-flex-between uk-flex-middle">
                    <div>
                        <h3 class="uk-card-title uk-margin-remove"><?php echo $active_students; ?></h3>
                        <p class="uk-text-meta uk-margin-remove">Active Students</p>
                    </div>
                    <span uk-icon="icon: check; ratio: 2.5"></span>
                </div>
            </div>
        </div>
        
        <div class="uk-width-1-4@m">
            <div class="uk-card uk-card-default uk-card-body">
                <div class="uk-flex uk-flex-between uk-flex-middle">
                    <div>
                        <h3 class="uk-card-title uk-margin-remove"><?php echo $total_programs; ?></h3>
                        <p class="uk-text-meta uk-margin-remove">Active Programs</p>
                    </div>
                    <span uk-icon="icon: album; ratio: 2.5"></span>
                </div>
            </div>
        </div>
        
        <div class="uk-width-1-4@m">
            <div class="uk-card uk-card-secondary uk-card-body">
                <div class="uk-flex uk-flex-between uk-flex-middle">
                    <div>
                        <h3 class="uk-card-title uk-margin-remove"><?php echo $recent_students; ?></h3>
                        <p class="uk-text-meta uk-margin-remove">New (7 Days)</p>
                    </div>
                    <span uk-icon="icon: plus-circle; ratio: 2.5"></span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Charts and Data 
    <div class="uk-grid-match" uk-grid>
        <!-- Status Distribution -->
        <div class="uk-width-1-2@m">
            <div class="uk-card uk-card-default uk-card-body">
                <h3 class="uk-card-title">Students by Status</h3>
                <canvas id="statusChart" height="200"></canvas>
                
                <div class="uk-margin-top">
                    <?php
                    $status_colors = [
                        'active' => 'success',
                        'inactive' => 'warning',
                        'graduated' => 'primary',
                        'dropped' => 'danger',
                        'on_leave' => 'secondary'
                    ];
                    foreach ($status_data as $status => $count):
                        $color = $status_colors[$status] ?? 'default';
                    ?>
                    <div class="uk-grid-small uk-margin-small" uk-grid>
                        <div class="uk-width-expand">
                            <span class="uk-label uk-label-<?php echo $color; ?>">
                                <?php echo ucfirst(str_replace('_', ' ', $status)); ?>
                            </span>
                        </div>
                        <div class="uk-width-auto">
                            <strong><?php echo $count; ?></strong>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <!-- Year Level Distribution 
        <div class="uk-width-1-2@m">
            <div class="uk-card uk-card-default uk-card-body">
                <h3 class="uk-card-title">Active Students by Year Level</h3>
                <canvas id="yearChart" height="200"></canvas>
                
                <div class="uk-margin-top">
                    <?php for ($i = 1; $i <= 5; $i++): 
                        $count = $year_data[$i] ?? 0;
                    ?>
                    <div class="uk-grid-small uk-margin-small" uk-grid>
                        <div class="uk-width-expand">
                            Year <?php echo $i; ?>
                        </div>
                        <div class="uk-width-auto">
                            <strong><?php echo $count; ?></strong>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
        
    </div>
    
                    -->
    <!-- Quick Actions -->
    <div class="uk-card uk-card-default uk-card-body uk-margin-top">
        <h3 class="uk-card-title">Quick Actions</h3>
        <div class="uk-grid-small" uk-grid>
            <div class="uk-width-auto@m">
                <a href="<?php echo $baseUrl; ?>/student/register" class="uk-button uk-button-primary">
                    <span uk-icon="plus"></span> Register New Student
                </a>
            </div>
            <div class="uk-width-auto@m">
                <a href="<?php echo $baseUrl; ?>/student/search" class="uk-button uk-button-default">
                    <span uk-icon="search"></span> Search Students
                </a>
            </div>
            <div class="uk-width-auto@m">
                <a href="<?php echo $baseUrl; ?>/status/tracking" class="uk-button uk-button-default">
                    <span uk-icon="users"></span> Status Tracking
                </a>
            </div>
            <div class="uk-width-auto@m">
                <a href="<?php echo $baseUrl; ?>/reports" class="uk-button uk-button-default">
                    <span uk-icon="print"></span> Generate Reports
                </a>
            </div>
        </div>
    </div>
    
    <!-- Recent Activity -->
    <div class="uk-card uk-card-default uk-card-body uk-margin-top">
        <h3 class="uk-card-title">Recent Activity</h3>
        <?php if (count($recent_logs) > 0): ?>
        <ul class="uk-list uk-list-divider">
            <?php foreach ($recent_logs as $log): ?>
            <li>
                <div class="uk-grid-small" uk-grid>
                    <div class="uk-width-expand">
                        <strong><?php echo ucfirst($log['action']); ?></strong>
                        in <?php echo ucfirst(str_replace('_', ' ', $log['module'])); ?>
                        <br>
                        <span class="uk-text-meta">
                            <?php echo $log['description']; ?>
                        </span>
                    </div>
                    <div class="uk-width-auto uk-text-right">
                        <span class="uk-text-small"><?php echo $log['username'] ?? 'System'; ?></span><br>
                        <span class="uk-text-meta">
                            <?php echo date('M d, Y h:i A', strtotime($log['created_at'])); ?>
                        </span>
                    </div>
                </div>
            </li>
            <?php endforeach; ?>
        </ul>
        <div class="uk-text-right">
            <a href="<?php echo $baseUrl; ?>/activity/logs" class="uk-button uk-button-text">View All Activity →</a>
        </div>
        <?php else: ?>
        <p class="uk-text-meta">No recent activity</p>
        <?php endif; ?>
    </div>
</div>


<!-- Simple Chart.js visualization 
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<script>
// Status Chart
const statusCtx = document.getElementById('statusChart');
if (statusCtx) {
    new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode(array_map(function($s) { return ucfirst(str_replace('_', ' ', $s)); }, array_keys($status_data))); ?>,
            datasets: [{
                data: <?php echo json_encode(array_values($status_data)); ?>,
                backgroundColor: [
                    '#32d296',  // active - green
                    '#faa05a',  // inactive - orange
                    '#1e87f0',  // graduated - blue
                    '#f0506e',  // dropped - red
                    '#666'      // on_leave - gray
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

// Year Chart
const yearCtx = document.getElementById('yearChart');
if (yearCtx) {
    new Chart(yearCtx, {
        type: 'bar',
        data: {
            labels: ['Year 1', 'Year 2', 'Year 3', 'Year 4', 'Year 5'],
            datasets: [{
                label: 'Students',
                data: [
                    <?php echo $year_data[1] ?? 0; ?>,
                    <?php echo $year_data[2] ?? 0; ?>,
                    <?php echo $year_data[3] ?? 0; ?>,
                    <?php echo $year_data[4] ?? 0; ?>,
                    <?php echo $year_data[5] ?? 0; ?>
                ],
                backgroundColor: '#1e87f0'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}
</script>

        -->
<?php require_once __DIR__ . '/includes/footer.php'; ?>
